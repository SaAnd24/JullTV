# JullTV v0.1

Launcher personal para Android TV 11 (API 30+), hecho con Kotlin y Jetpack Compose (Material 3).

**Qué hace la v0.1:** pantalla de inicio cinematográfica, hora, acceso a ajustes, fila de aplicaciones de TV instaladas
(nombre e icono/banner reales), sección «Todas las aplicaciones», navegación completa con el mando (flechas, OK, Atrás)
y registro de errores con la etiqueta `JullTV`. No incluye recomendaciones, catálogos ni historial: eso llegará en futuras versiones.

> Este proyecto no se ha compilado ni probado en el entorno donde se generó. La primera compilación en GitHub Actions
> es la verificación real: si falla, copia el error del log y se corrige.

## 1. Subir el proyecto a GitHub
1. Crea un repositorio nuevo en GitHub (vacío, sin README).
2. Descomprime el ZIP y sube **el contenido** de la carpeta `JullTV` a la raíz del repositorio
   (en la web: *Add file → Upload files*; arrastra los archivos y carpetas; `settings.gradle.kts` debe quedar en la raíz).
3. Crea el workflow: *Add file → Create new file*, escribe como nombre `.github/workflows/build.yml`
   y pega el contenido del `build.yml` que te di en el chat. Pulsa *Commit changes*.

## 2. Ejecutar el workflow y descargar el APK
1. Ve a la pestaña **Actions**. Se ejecuta solo al hacer commit en `main`/`master`; también puedes pulsar
   *Build debug APK → Run workflow*.
2. Cuando termine en verde, entra en la ejecución y en **Artifacts** descarga `JullTV-debug-apk` (ZIP con `app-debug.apk`).
3. Si falla, abre el paso rojo y copia el error.

## 3. Instalar en Android TV
- Pasa `app-debug.apk` a un USB e instálalo con un explorador de archivos (activa *Orígenes desconocidos* para esa app), o
- Con ADB por red: `adb connect IP_DEL_TV:5555` y luego `adb install app-debug.apk`.

## 4. Seleccionar JullTV como launcher
- Ábrelo desde la lista de aplicaciones para probarlo.
- Para usarlo como pantalla de inicio: *Ajustes → Aplicaciones → Aplicaciones predeterminadas → Pantalla de inicio*
  (el nombre del menú varía según el fabricante) y elige JullTV. Si tu TV no ofrece esa opción, el sistema no permite cambiar de launcher.
- Para volver al anterior, elige de nuevo el launcher original en ese mismo menú.

## Diagnóstico
`adb logcat -s JullTV`

## Estructura
- `app/src/main/java/com/jull/tv/data`: lectura de apps (`AppRepository`) y puntos de extensión futuros.
- `app/src/main/java/com/jull/tv/ui`: pantallas y componentes Compose.
- `app/src/main/java/com/jull/tv/util`: apertura de apps y registro.

## Nota sobre Gradle Wrapper
El workflow instala Gradle 8.7 directamente. Si quieres usar `./gradlew` en local, ejecuta una vez `gradle wrapper --gradle-version 8.7`.
