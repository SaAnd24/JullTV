package com.jull.tv.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jull.tv.R
import com.jull.tv.data.InstalledApp
import com.jull.tv.ui.theme.JullColors
import kotlinx.coroutines.delay

@Composable
fun CinematicBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            Brush.verticalGradient(listOf(Color(0xFF07151B), JullColors.Background)),
        )
        val center = Offset(size.width * 0.85f, size.height * 0.1f)
        val radius = size.width * 0.6f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(JullColors.Turquoise.copy(alpha = 0.16f), Color.Transparent),
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )
    }
}

@Composable
private fun HeroPanel(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(28.dp)
    Box(modifier = modifier.clip(shape)) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                Brush.linearGradient(
                    colors = listOf(Color(0xFF0B4A4A), Color(0xFF071014)),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height),
                ),
            )
            val c = Offset(size.width * 0.82f, size.height * 0.5f)
            val glow = size.height * 1.4f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(JullColors.Turquoise.copy(alpha = 0.35f), Color.Transparent),
                    center = c,
                    radius = glow,
                ),
                radius = glow,
                center = c,
            )
            for (i in 1..4) {
                drawCircle(
                    color = JullColors.Turquoise.copy(alpha = 0.12f),
                    radius = size.height * 0.28f * i,
                    center = c,
                    style = Stroke(width = 2.dp.toPx()),
                )
            }
            val s = size.height * 0.3f
            val play = Path().apply {
                moveTo(c.x - s * 0.35f, c.y - s * 0.5f)
                lineTo(c.x + s * 0.55f, c.y)
                lineTo(c.x - s * 0.35f, c.y + s * 0.5f)
                close()
            }
            drawPath(play, JullColors.Turquoise.copy(alpha = 0.25f))
        }
        // Degradado oscuro para garantizar la legibilidad del texto
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent),
                    ),
                ),
        )
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 40.dp),
        ) {
            Text(
                text = stringResource(R.string.tagline),
                color = JullColors.TextPrimary,
                fontSize = 38.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 44.sp,
                modifier = Modifier.fillMaxWidth(0.62f),
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = stringResource(R.string.tagline_sub),
                color = JullColors.TextSecondary,
                fontSize = 20.sp,
                modifier = Modifier.fillMaxWidth(0.55f),
            )
        }
    }
}

@Composable
fun EmptyState(failed: Boolean, onRetry: () -> Unit, retryFocus: FocusRequester, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = stringResource(R.string.no_apps_title),
            color = JullColors.TextPrimary,
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = stringResource(if (failed) R.string.apps_error_body else R.string.no_apps_body),
            color = JullColors.TextSecondary,
            fontSize = 20.sp,
        )
        Spacer(Modifier.height(6.dp))
        TvButton(
            text = stringResource(R.string.retry),
            onClick = onRetry,
            modifier = Modifier.focusRequester(retryFocus),
        )
    }
}

@Composable
fun HomeScreen(
    state: AppsUiState,
    onOpenApp: (InstalledApp) -> Unit,
    onOpenAll: () -> Unit,
    onOpenSettings: () -> Unit,
    onRetry: () -> Unit,
) {
    val tvApps = remember(state.apps) { state.apps.filter { it.isTv } }
    // Si no hay apps de TV, se muestran las demás para no dejar la fila vacía.
    val homeApps = if (tvApps.isNotEmpty()) tvApps else state.apps
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(state.loading, homeApps.size) {
        delay(200)
        runCatching { firstFocus.requestFocus() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 48.dp, vertical = 27.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = stringResource(R.string.app_name),
                color = JullColors.Turquoise,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                ClockText()
                Spacer(Modifier.width(20.dp))
                SettingsButton(onClick = onOpenSettings)
            }
        }

        Spacer(Modifier.height(14.dp))
        HeroPanel(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
        )
        Spacer(Modifier.height(14.dp))

        Text(
            text = stringResource(R.string.my_apps),
            color = JullColors.TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
        )

        when {
            state.loading && homeApps.isEmpty() -> {
                Text(
                    text = stringResource(R.string.loading),
                    color = JullColors.TextSecondary,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(vertical = 24.dp),
                )
            }
            homeApps.isEmpty() -> {
                EmptyState(
                    failed = state.failed,
                    onRetry = onRetry,
                    retryFocus = firstFocus,
                    modifier = Modifier.padding(vertical = 12.dp),
                )
            }
            else -> {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 16.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    itemsIndexed(homeApps, key = { _, app -> app.key }) { index, app ->
                        AppCard(
                            app = app,
                            onClick = { onOpenApp(app) },
                            modifier = if (index == 0) Modifier.focusRequester(firstFocus) else Modifier,
                        )
                    }
                    item(key = "all_apps") {
                        ActionCard(
                            label = stringResource(R.string.all_apps),
                            icon = Icons.Filled.Menu,
                            onClick = onOpenAll,
                        )
                    }
                }
            }
        }
    }
}
