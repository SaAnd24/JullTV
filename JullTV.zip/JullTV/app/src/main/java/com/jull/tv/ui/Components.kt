package com.jull.tv.ui

import android.content.Context
import android.text.format.DateFormat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.jull.tv.R
import com.jull.tv.data.InstalledApp
import com.jull.tv.ui.theme.JullColors
import kotlinx.coroutines.delay
import java.util.Date

private val CardWidth = 200.dp

/** Contorno turquesa discreto con brillo suave cuando el elemento tiene el foco. */
@Composable
fun Modifier.focusGlow(focused: Boolean, shape: Shape): Modifier {
    val elevation by animateDpAsState(if (focused) 18.dp else 0.dp, tween(140), label = "glowElevation")
    val borderColor by animateColorAsState(
        if (focused) JullColors.Turquoise else Color.White.copy(alpha = 0.08f),
        tween(140),
        label = "glowBorder",
    )
    val borderWidth = if (focused) 3.dp else 1.dp
    return this
        .shadow(
            elevation = elevation,
            shape = shape,
            clip = false,
            ambientColor = JullColors.Turquoise,
            spotColor = JullColors.Turquoise,
        )
        .border(borderWidth, borderColor, shape)
}

/** Tarjeta base 16:9 con texto debajo. Se activa con OK/Enter. */
@Composable
fun TvCard(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(if (focused) 1.08f else 1f, tween(140), label = "cardScale")
    val shape = RoundedCornerShape(16.dp)

    Column(
        modifier = modifier
            .width(CardWidth)
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .focusGlow(focused, shape)
                .clip(shape)
                .background(JullColors.Surface),
            content = content,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = label,
            color = if (focused) JullColors.TextPrimary else JullColors.TextSecondary,
            fontSize = 18.sp,
            fontWeight = if (focused) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
fun AppCard(app: InstalledApp, onClick: () -> Unit, modifier: Modifier = Modifier) {
    TvCard(label = app.label, onClick = onClick, modifier = modifier) {
        if (app.isBanner) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(64.dp),
            )
        }
    }
}

@Composable
fun ActionCard(label: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    TvCard(label = label, onClick = onClick, modifier = modifier) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = JullColors.Turquoise,
            modifier = Modifier
                .align(Alignment.Center)
                .size(44.dp),
        )
    }
}

@Composable
fun TvButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .focusGlow(focused, shape)
            .clip(shape)
            .background(if (focused) JullColors.TurquoiseDeep else JullColors.SurfaceHigh)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 28.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = text, color = JullColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SettingsButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .size(44.dp)
            .focusGlow(focused, CircleShape)
            .clip(CircleShape)
            .background(if (focused) JullColors.TurquoiseDeep else JullColors.SurfaceHigh)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.Settings,
            contentDescription = stringResource(R.string.settings),
            tint = JullColors.TextPrimary,
            modifier = Modifier.size(26.dp),
        )
    }
}

@Composable
fun ClockText(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val time by produceState(initialValue = formatTime(context)) {
        while (true) {
            value = formatTime(context)
            delay(15_000)
        }
    }
    Text(
        text = time,
        color = JullColors.TextPrimary,
        fontSize = 24.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier,
    )
}

private fun formatTime(context: Context): String =
    DateFormat.getTimeFormat(context).format(Date())
