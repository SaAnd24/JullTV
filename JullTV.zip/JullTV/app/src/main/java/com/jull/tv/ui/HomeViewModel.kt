package com.jull.tv.ui

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jull.tv.data.AppRepository
import com.jull.tv.data.InstalledApp
import com.jull.tv.util.AppLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@Immutable
data class AppsUiState(
    val loading: Boolean = true,
    val apps: List<InstalledApp> = emptyList(),
    val failed: Boolean = false,
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val _state = MutableStateFlow(AppsUiState())
    val state: StateFlow<AppsUiState> = _state.asStateFlow()

    /** true cuando se muestra la pantalla «Todas las aplicaciones». */
    var allAppsOpen by mutableStateOf(false)

    private var job: Job? = null

    fun refresh() {
        job?.cancel()
        job = viewModelScope.launch {
            try {
                val apps = repository.loadApps()
                _state.value = AppsUiState(loading = false, apps = apps)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                AppLog.e("Fallo al cargar aplicaciones", e)
                _state.value = AppsUiState(loading = false, apps = emptyList(), failed = true)
            }
        }
    }
}
