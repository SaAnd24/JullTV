package com.jull.tv.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.util.AppLauncher

@Composable
fun JullRoot(viewModel: HomeViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Atrás: cierra «Todas las aplicaciones»; en el inicio no hace nada (es el launcher).
    BackHandler(enabled = true) {
        if (viewModel.allAppsOpen) viewModel.allAppsOpen = false
    }

    Box(Modifier.fillMaxSize()) {
        CinematicBackground()
        Crossfade(
            targetState = viewModel.allAppsOpen,
            animationSpec = tween(180),
            label = "screen",
        ) { showAll ->
            if (showAll) {
                AllAppsScreen(
                    state = state,
                    onOpenApp = { AppLauncher.launch(context, it) },
                    onRetry = viewModel::refresh,
                )
            } else {
                HomeScreen(
                    state = state,
                    onOpenApp = { AppLauncher.launch(context, it) },
                    onOpenAll = { viewModel.allAppsOpen = true },
                    onOpenSettings = { AppLauncher.openSystemSettings(context) },
                    onRetry = viewModel::refresh,
                )
            }
        }
    }
}
