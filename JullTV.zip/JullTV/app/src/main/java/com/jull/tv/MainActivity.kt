package com.jull.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.jull.tv.ui.HomeViewModel
import com.jull.tv.ui.JullRoot
import com.jull.tv.ui.theme.JullTheme
import com.jull.tv.util.AppLog

class MainActivity : ComponentActivity() {

    private val viewModel: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.d("JullTV iniciado")
        setContent {
            JullTheme {
                JullRoot(viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pulsar Inicio estando en «Todas las aplicaciones» vuelve a la pantalla principal.
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            viewModel.allAppsOpen = false
        }
    }

    override fun onResume() {
        super.onResume()
        // Al volver de otra app, se actualiza la lista (instalaciones/desinstalaciones).
        viewModel.refresh()
    }
}
