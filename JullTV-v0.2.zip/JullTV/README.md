# JullTV v0.2 — catálogo, recomendaciones y «Continuar viendo»

Launcher personal para Android TV 11 (API 30+) hecho con Kotlin y Jetpack Compose.
La v0.2 evoluciona la v0.1 (launcher, apps, mando, foco turquesa) sin quitar nada.

> **Estado de la compilación:** este proyecto se escribió y revisó a mano, **sin compilarlo ni probarlo**
> (el entorno donde se generó no tiene Gradle ni red). La primera compilación en GitHub Actions es la verificación real.
> Si falla, copia el error del log y se corrige.

## Qué incluye

**Heredado de la v0.1:** launcher HOME + LEANBACK, detección de apps (YouTube y Xuper TV primero), fila de apps,
«Todas las aplicaciones», apertura segura, hora, ajustes, navegación con flechas / OK / Atrás, foco turquesa.

**Nuevo en la v0.2:**
- Inicio con destacado: la imagen panorámica del título enfocado cambia el fondo (degradado oscuro para leer el texto).
- Filas: Mis aplicaciones · Continuar viendo · Explorar · Para descubrir · Según tus intereses.
- Explorar películas, series, anime (TMDB) y YouTube; búsqueda; ficha de contenido; relacionados; «Ver más» (paginación).
- «Dónde ver» (proveedores de TMDB para Ecuador) marcando las apps que tienes instaladas. Es una referencia **sin verificar**.
- Seguimiento local: pendiente / en curso / terminado, progreso, temporada y episodio **anotados por ti**, favoritos, actividad.
- Intereses: tipos preferidos, géneros favoritos y géneros excluidos. Reglas transparentes, sin IA.
- Ajustes y diagnóstico: conexión, estado de TMDB y YouTube, integraciones, gestión del historial, atribuciones.

## Qué funciona sin claves y qué necesita configuración

| Función | Sin claves | Con TMDB_API_KEY | Con YOUTUBE_API_KEY |
|---|---|---|---|
| Launcher, apps, «Todas las aplicaciones» | Sí | Sí | Sí |
| Seguimiento local, favoritos, intereses | Sí (sin pósters de TMDB nuevos) | Sí | Sí |
| Películas, series, anime, fichas, búsqueda, dónde ver | No (mensaje explicativo) | Sí | Sí |
| Vídeos populares y búsqueda de vídeos/canales | No; sí búsqueda oficial de YouTube y abrir la app | — | Sí |

## 1. Subir el proyecto a GitHub (desde el teléfono)
1. Entra en github.com con el navegador (activa «Sitio de escritorio» si hace falta) y abre tu repositorio.
2. Sube el contenido de este ZIP (*Add file → Upload files*) **o** el propio `JullTV-v0.2.zip`.
   Si ya tenías el ZIP de la v0.1 en el repositorio, bórralo o sustitúyelo para que no haya dos versiones.
3. Comprueba que `.github/workflows/build.yml` tenga el contenido del `build.yml` entregado en el chat
   (esta versión lo actualiza para pasar las claves a la compilación).

## 2. Configurar las claves como secretos (opcional pero recomendado)
**TMDB (catálogo):**
1. Crea una cuenta gratuita en themoviedb.org → Configuración → API → solicita una clave (uso personal).
2. Copia la «Clave de la API» (v3) o el «Token de acceso de lectura» (v4); ambos sirven.
3. En tu repositorio: **Settings → Secrets and variables → Actions → New repository secret**.
   Nombre: `TMDB_API_KEY` · Valor: tu clave. Guarda.

**YouTube Data API (opcional):**
1. En console.cloud.google.com crea un proyecto, activa «YouTube Data API v3» y crea una *clave de API*.
2. Crea el secreto `YOUTUBE_API_KEY` igual que el anterior.
3. Cuota gratuita: 10 000 unidades/día. Cada búsqueda gasta unas 200 (vídeos + canales), los populares 1.

> Las claves no están en el código ni en el repositorio. **Pero quedan dentro del APK** y pueden extraerse de él:
> no compartas el APK y, si lo haces, restringe/rota las claves.

## 3. Compilar, descargar e instalar
1. Pestaña **Actions → Build debug APK → Run workflow** (también corre solo al hacer commit).
2. Al terminar en verde, abre la ejecución y descarga el artefacto **JullTV-debug-apk** (ZIP con `app-debug.apk`).
3. Instala el APK en el TV (USB + explorador de archivos con *orígenes desconocidos*, o `adb install`).
4. Si cambias una clave, **vuelve a compilar**: se incrusta al compilar.

## 4. Seleccionar JullTV como launcher
Ajustes del TV → Aplicaciones → Aplicaciones predeterminadas → Pantalla de inicio (el nombre varía según el fabricante).
JullTV también ofrece «Ajustes del sistema» desde su pantalla de Ajustes. Para volver, elige tu launcher anterior en el mismo menú.

## 5. Limitaciones verificadas por diseño (léelas)
- **Historial de otras apps:** JullTV **no** lee el historial ni el progreso de YouTube, Xuper TV ni ninguna app.
  «Continuar viendo» usa solo lo que tú anotas en JullTV.
- **Abrir una app no es reproducir:** abrir una app desde JullTV y volver queda registrado como *actividad*
  («abierto desde JullTV», «regreso al launcher»); no demuestra que viste algo.
- **Xuper TV:** no se asume API, catálogo ni deep links. Solo se abre la app y tú buscas el título.
- **YouTube:** los vídeos/canales se abren con enlaces oficiales; si el TV los acepta depende de la app de YouTube
  instalada (marcado «sin verificar» en Ajustes). Solo datos públicos.
- **Dónde ver:** datos de JustWatch vía TMDB para Ecuador; no confirman acceso directo, gratuidad ni suscripción.
- **Anime:** se detecta como animación (género 16) con idioma original japonés; puede haber falsos positivos/negativos.
- **Idioma:** `es-MX` (TMDB no ofrece variante de Ecuador); si falta la sinopsis se muestra la inglesa avisándolo.
- **Logo de TMDB:** se incluye la declaración de atribución exigida en Ajustes, pero **no el logotipo** oficial
  (no se pudo descargar en el entorno de generación). Añádelo antes de distribuir la app.
- **Gradle Wrapper:** no se incluye `gradle-wrapper.jar` (no se pudo generar sin red); el workflow instala Gradle 8.7.

## Estructura
- `config/` claves y región · `net/` HTTP con timeouts y caché · `catalog/` TMDB y modelos · `youtube/` YouTube API
- `local/` historial, seguimiento, favoritos y preferencias (JSON privado en el dispositivo)
- `reco/` reglas de recomendación · `integration/` estados de integración por app
- `ui/` pantallas Compose · `data/` apps instaladas (v0.1) · `util/` apertura de apps y registro

## Diagnóstico
`adb logcat -s JullTV` (las claves se ocultan en los registros).
