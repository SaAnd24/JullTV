package com.jull.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.local.Interest
import com.jull.tv.reco.Genres

@Composable
fun InterestsScreen(nav: HomeViewModel, catalog: CatalogViewModel) {
    val store by catalog.storeState.collectAsStateWithLifecycle()
    val prefs = store.prefs
    val first = rememberScreenFocus(nav.focus)

    ScreenScaffold(
        title = "Mis intereses",
        subtitle = "Las recomendaciones usan solo lo que eliges aquí, tus favoritos y tu actividad en JullTV",
    ) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 190.dp),
            contentPadding = PaddingValues(bottom = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item(key = "h_kinds", span = { GridItemSpan(maxLineSpan) }) {
                SectionTitle("Qué prefieres ver")
            }
            items(Interest.values().toList(), key = { "kind_" + it.name }) { interest ->
                TvButton(
                    text = interest.label,
                    onClick = { catalog.store.toggleInterest(interest) },
                    selected = interest in prefs.interests,
                    modifier = if (interest == Interest.MOVIES) Modifier.focusRequester(first) else Modifier,
                )
            }
            item(key = "h_fav", span = { GridItemSpan(maxLineSpan) }) {
                SectionTitle("Géneros favoritos")
            }
            items(Genres.all, key = { "fav_" + it.id }) { g ->
                TvButton(
                    text = g.label,
                    onClick = { catalog.store.toggleFavoriteGenre(g.id) },
                    selected = g.id in prefs.favoriteGenres,
                )
            }
            item(key = "h_exc", span = { GridItemSpan(maxLineSpan) }) {
                SectionTitle("Géneros a excluir")
            }
            items(Genres.all, key = { "exc_" + it.id }) { g ->
                TvButton(
                    text = g.label,
                    onClick = { catalog.store.toggleExcludedGenre(g.id) },
                    selected = g.id in prefs.excludedGenres,
                    selectedColor = Color(0xFF7F1D1D),
                )
            }
            item(key = "h_note", span = { GridItemSpan(maxLineSpan) }) {
                InfoText("Los cambios se aplican al volver al inicio. Los títulos favoritos generan recomendaciones relacionadas.")
            }
        }
    }
}
