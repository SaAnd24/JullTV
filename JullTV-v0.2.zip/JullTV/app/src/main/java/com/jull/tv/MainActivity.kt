package com.jull.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.jull.tv.ui.CatalogViewModel
import com.jull.tv.ui.HomeViewModel
import com.jull.tv.ui.JullRoot
import com.jull.tv.ui.theme.JullTheme
import com.jull.tv.util.AppLog

class MainActivity : ComponentActivity() {

    private val viewModel: HomeViewModel by viewModels()
    private val catalog: CatalogViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.d("JullTV iniciado")
        setContent {
            JullTheme {
                JullRoot(viewModel, catalog)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pulsar Inicio vuelve a la pantalla principal.
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            viewModel.goHome()
        }
    }

    override fun onResume() {
        super.onResume()
        // Al volver de otra app: actualiza apps instaladas, registra el regreso y reintenta filas con error.
        viewModel.refresh()
        catalog.onLauncherResumed()
        catalog.retryFailedRows()
    }
}
