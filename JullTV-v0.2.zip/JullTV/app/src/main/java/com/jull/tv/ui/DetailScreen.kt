package com.jull.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Images
import com.jull.tv.catalog.Kind
import com.jull.tv.data.InstalledApp
import com.jull.tv.integration.Integrations
import com.jull.tv.local.WatchStatus
import com.jull.tv.ui.theme.JullColors
import com.jull.tv.util.AppLauncher
import com.jull.tv.youtube.YouTubeClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DetailScreen(
    item: ContentItem,
    nav: HomeViewModel,
    catalog: CatalogViewModel,
    appsState: AppsUiState,
) {
    val context = LocalContext.current
    val store by catalog.storeState.collectAsStateWithLifecycle()
    val detailMap by catalog.details.collectAsStateWithLifecycle()
    val rows by catalog.rows.collectAsStateWithLifecycle()
    val first = rememberScreenFocus(nav.focus)

    LaunchedEffect(item.key) { catalog.loadDetail(item) }

    val apps = appsState.apps
    val tracked = store.tracked.firstOrNull { it.item.key == item.key }
    val isFav = store.favorites.any { it.key == item.key }
    val ds = detailMap[item.key]
    val details = ds?.details
    val isChannel = item.kind == Kind.YOUTUBE_CHANNEL
    val prov = ds?.providers
    val provError = ds?.providersError
    val provLoading = item.isTmdb && (ds == null || ds.loading)

    val providerNames = if (prov != null) (prov.flatrate + prov.free + prov.rent + prov.buy).distinct() else emptyList()
    val matchedApps = apps.filter { a -> providerNames.any { Integrations.matchesProvider(a, it) } }
    val openTargets = (matchedApps + apps.filter { Integrations.isPinned(it) }).distinctBy { it.packageName }.take(5)
    val sourceApp = tracked?.sourcePackage?.let { pkg -> apps.firstOrNull { it.packageName == pkg } }
    val dateFmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale("es", "EC")) }
    val openItem: (ContentItem) -> Unit = { nav.push(Screen.Detail(it)) }

    fun openInApp(app: InstalledApp) {
        if (AppLauncher.launch(context, app)) catalog.onOpenedFromJull(item, app.packageName)
    }

    fun openInYouTube() {
        val id = item.youtubeId ?: return
        val url = if (isChannel) YouTubeClient.channelUrl(id) else YouTubeClient.videoUrl(id)
        val pkg = apps.firstOrNull { Integrations.isYouTube(it) }?.packageName
        if (AppLauncher.openUrl(context, url, pkg)) catalog.onOpenedFromJull(item, pkg)
    }

    fun installedTag(name: String): String =
        if (apps.any { Integrations.matchesProvider(it, name) }) "$name (app instalada)" else name

    LazyColumn(
        state = nav.listState("detail:${item.key}"),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 27.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // ----- Cabecera -----
        item(key = "header") {
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                Box(
                    Modifier
                        .width(if (item.isTmdb) 150.dp else 260.dp)
                        .aspectRatio(if (item.isTmdb) 2f / 3f else 16f / 9f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(JullColors.Surface),
                ) {
                    RemoteImage(Images.poster(item.posterPath, "w342"), Modifier.fillMaxSize(), ContentScale.Crop)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = item.title,
                        color = JullColors.TextPrimary,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val meta = buildList {
                        add(item.kind.label)
                        item.year?.let { add(it) }
                        details?.runtimeMinutes?.let { add("$it min") }
                        details?.seasons?.let { add(if (it == 1) "1 temporada" else "$it temporadas") }
                        item.channelTitle?.let { add(it) }
                    }.joinToString(" · ")
                    InfoText(meta, color = JullColors.Turquoise)
                    item.rating?.let {
                        InfoText("Valoración de TMDB: ${String.format(Locale.US, "%.1f", it)}/10")
                    }
                    if (details != null && details.genres.isNotEmpty()) {
                        InfoText(details.genres.joinToString(", "))
                    }
                    val overview = details?.overview ?: item.overview
                    Text(
                        text = overview ?: if (ds == null || ds.loading) "Cargando sinopsis…" else "Sin sinopsis disponible.",
                        color = JullColors.TextPrimary,
                        fontSize = 18.sp,
                        maxLines = 6,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (details?.overviewIsFallbackLanguage == true) {
                        InfoText("Sinopsis en inglés: TMDB no tiene versión en español.")
                    }
                    if (ds?.error != null) InfoText("No se pudieron cargar todos los datos: ${ds.error}")
                }
            }
        }

        // ----- Acciones -----
        item(key = "actions") {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                item(key = "fav") {
                    TvButton(
                        text = if (isFav) "Quitar de favoritos" else "Añadir a favoritos",
                        onClick = { catalog.store.toggleFavorite(item) },
                        modifier = Modifier.focusRequester(first),
                    )
                }
                if (!isChannel) {
                    if (tracked == null) {
                        item(key = "add") {
                            TvButton("Añadir a Continuar viendo", { catalog.store.track(item, WatchStatus.PENDING) })
                        }
                    } else {
                        item(key = "st_pending") {
                            TvButton(
                                "Pendiente",
                                { catalog.store.track(item, WatchStatus.PENDING) },
                                selected = tracked.status == WatchStatus.PENDING,
                            )
                        }
                        item(key = "st_progress") {
                            TvButton(
                                "En curso",
                                { catalog.store.track(item, WatchStatus.IN_PROGRESS) },
                                selected = tracked.status == WatchStatus.IN_PROGRESS,
                            )
                        }
                        item(key = "st_done") {
                            TvButton(
                                "Terminado",
                                { catalog.store.track(item, WatchStatus.FINISHED) },
                                selected = tracked.status == WatchStatus.FINISHED,
                            )
                        }
                        item(key = "remove") {
                            TvButton("Quitar del historial", { catalog.store.remove(item.key) })
                        }
                    }
                }
                if (item.isYoutube) {
                    item(key = "yt_open") {
                        TvButton(
                            text = if (isChannel) "Abrir canal en YouTube" else "Abrir en YouTube",
                            onClick = { openInYouTube() },
                        )
                    }
                }
            }
        }

        // ----- Progreso manual -----
        if (tracked != null && !isChannel) {
            item(key = "progress") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Tu progreso (lo anotas tú)")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                        item(key = "pct") {
                            Stepper(
                                label = "Progreso",
                                valueText = tracked.progressPercent?.let { "$it%" } ?: "sin registrar",
                                onMinus = {
                                    val cur = tracked.progressPercent
                                    catalog.store.setPercent(item.key, if (cur == null || cur <= 5) null else cur - 5)
                                },
                                onPlus = {
                                    catalog.store.setPercent(item.key, ((tracked.progressPercent ?: 0) + 5).coerceAtMost(100))
                                },
                            )
                        }
                        if (item.kind == Kind.SERIES || item.kind == Kind.ANIME) {
                            item(key = "season") {
                                Stepper(
                                    label = "Temporada",
                                    valueText = tracked.season?.toString() ?: "—",
                                    onMinus = {
                                        val cur = tracked.season
                                        catalog.store.setSeason(item.key, if (cur == null || cur <= 1) null else cur - 1)
                                    },
                                    onPlus = { catalog.store.setSeason(item.key, (tracked.season ?: 0) + 1) },
                                )
                            }
                            item(key = "episode") {
                                Stepper(
                                    label = "Episodio",
                                    valueText = tracked.episode?.toString() ?: "—",
                                    onMinus = {
                                        val cur = tracked.episode
                                        catalog.store.setEpisode(item.key, if (cur == null || cur <= 1) null else cur - 1)
                                    },
                                    onPlus = { catalog.store.setEpisode(item.key, (tracked.episode ?: 0) + 1) },
                                )
                            }
                        }
                    }
                    InfoText("JullTV no mide la reproducción de otras aplicaciones: estos datos son los que tú anotas.")
                    tracked.lastOpenedAt?.let {
                        InfoText("Última apertura desde JullTV: ${dateFmt.format(Date(it))} (no confirma que se haya visto).")
                    }
                    tracked.lastReturnAt?.let {
                        InfoText("Último regreso al launcher: ${dateFmt.format(Date(it))} (no confirma el final de la reproducción).")
                    }
                }
            }
        }

        // ----- Abrir en una aplicación (solo contenido de TMDB) -----
        if (item.isTmdb) {
            item(key = "open_apps") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Abrir en una aplicación")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        if (sourceApp != null) {
                            item(key = "continue_in") {
                                TvButton("Continuar en ${sourceApp.label}", { openInApp(sourceApp) })
                            }
                        }
                        items(openTargets, key = { it.packageName }) { app ->
                            TvButton("Abrir ${app.label}", { openInApp(app) })
                        }
                    }
                    if (openTargets.isEmpty() && sourceApp == null) {
                        InfoText("No se detectaron aplicaciones relacionadas con este título.")
                    }
                    InfoText(
                        "JullTV no puede saber si YouTube, Xuper TV u otra aplicación tiene este título; " +
                            "se abre la aplicación y debes buscarlo allí.",
                    )
                }
            }

            // ----- Dónde ver -----
            item(key = "providers") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle("Dónde ver (según TMDB · Ecuador)")
                    when {
                        provLoading -> InfoText("Consultando disponibilidad…")
                        provError != null -> InfoText("No se pudo consultar la disponibilidad: $provError")
                        prov == null -> InfoText("Disponibilidad no confirmada.")
                        !prov.regionFound -> InfoText("TMDB no informa proveedores para Ecuador. Disponibilidad no confirmada.")
                        else -> {
                            val groups = listOf(
                                "Suscripción" to prov.flatrate,
                                "Gratis o con anuncios" to prov.free,
                                "Alquiler" to prov.rent,
                                "Compra" to prov.buy,
                            ).filter { it.second.isNotEmpty() }
                            if (groups.isEmpty()) {
                                InfoText("TMDB no lista proveedores para este título en Ecuador.")
                            }
                            for (g in groups) {
                                InfoText("${g.first}: ${g.second.joinToString(", ") { installedTag(it) }}")
                            }
                        }
                    }
                    InfoText(
                        "Datos de proveedores: JustWatch, vía TMDB. Son una referencia sin verificar: " +
                            "no confirman acceso directo, gratuidad ni que el título esté en Xuper TV.",
                    )
                }
            }

            // ----- Relacionados -----
            item(key = "related") {
                ContentRow(
                    rowId = "rel_${item.key}",
                    state = rows["rel_${item.key}"],
                    nav = nav,
                    catalog = catalog,
                    onOpen = openItem,
                    updateHero = false,
                )
            }
        }
    }
}
