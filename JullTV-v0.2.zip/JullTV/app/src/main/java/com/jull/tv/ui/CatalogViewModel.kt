package com.jull.tv.ui

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Details
import com.jull.tv.catalog.MAX_ROW_ITEMS
import com.jull.tv.catalog.Page
import com.jull.tv.catalog.Providers
import com.jull.tv.catalog.RowState
import com.jull.tv.catalog.RowStatus
import com.jull.tv.catalog.Section
import com.jull.tv.catalog.TmdbClient
import com.jull.tv.config.AppConfig
import com.jull.tv.local.LocalStore
import com.jull.tv.local.StoreState
import com.jull.tv.local.WatchStatus
import com.jull.tv.local.Interest
import com.jull.tv.net.ApiResult
import com.jull.tv.reco.Genres
import com.jull.tv.reco.RecommendationRepository
import com.jull.tv.reco.filtered
import com.jull.tv.youtube.YouTubeClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

enum class LoadStatus { IDLE, LOADING, READY, ERROR, NOT_CONFIGURED }

@Immutable
data class SearchUi(
    val query: String = "",
    val tmdbStatus: LoadStatus = LoadStatus.IDLE,
    val tmdbItems: List<ContentItem> = emptyList(),
    val tmdbError: String? = null,
    val ytStatus: LoadStatus = LoadStatus.IDLE,
    val ytVideos: List<ContentItem> = emptyList(),
    val ytChannels: List<ContentItem> = emptyList(),
    val ytError: String? = null,
)

@Immutable
data class DetailState(
    val loading: Boolean = true,
    val details: Details? = null,
    val error: String? = null,
    val providers: Providers? = null,
    val providersError: String? = null,
)

private data class HomeSig(
    val interests: Set<Interest>,
    val favGenres: Set<String>,
    val excGenres: Set<String>,
    val favKeys: List<String>,
    val activeKey: String?,
)

/** Catálogo, recomendaciones, búsqueda, fichas y seguimiento local. */
class CatalogViewModel(application: Application) : AndroidViewModel(application) {

    private val tmdb = TmdbClient()
    private val youtube = YouTubeClient()
    private val reco = RecommendationRepository(tmdb, youtube)

    val store = LocalStore(File(application.filesDir, "jull_state.json"), viewModelScope)
    val storeState: StateFlow<StoreState> = store.state

    // ---------- Filas paginadas ----------
    private val fetchers = HashMap<String, suspend (Int) -> ApiResult<Page>>()
    private val gens = HashMap<String, Int>()
    private val loading = HashSet<String>()
    private val _rows = MutableStateFlow<Map<String, RowState>>(emptyMap())
    val rows: StateFlow<Map<String, RowState>> = _rows.asStateFlow()

    private val _discoverIds = MutableStateFlow<List<String>>(emptyList())
    val discoverIds: StateFlow<List<String>> = _discoverIds.asStateFlow()
    private val _interestIds = MutableStateFlow<List<String>>(emptyList())
    val interestIds: StateFlow<List<String>> = _interestIds.asStateFlow()

    // ---------- Destacado (fondo de la pantalla de inicio) ----------
    private val _featured = MutableStateFlow<ContentItem?>(null)
    val featured: StateFlow<ContentItem?> = _featured.asStateFlow()
    private var featuredJob: Job? = null

    // ---------- Búsqueda y fichas ----------
    private val _search = MutableStateFlow(SearchUi())
    val search: StateFlow<SearchUi> = _search.asStateFlow()
    private var searchJob: Job? = null

    private val _details = MutableStateFlow<Map<String, DetailState>>(emptyMap())
    val details: StateFlow<Map<String, DetailState>> = _details.asStateFlow()
    private val relatedOrder = ArrayList<String>()

    // Apertura de otras apps desde JullTV (no prueba reproducción)
    private var pendingOpen: Pair<String, String?>? = null

    init {
        store.load()
        viewModelScope.launch {
            store.loaded.first { it }
            store.state.map { sig(it) }.distinctUntilChanged().collect { rebuildHome(it) }
        }
    }

    private fun sig(s: StoreState): HomeSig {
        val favKeys = s.favorites.filter { it.isTmdb }.take(2).map { it.key }
        val active = s.tracked
            .filter { it.status == WatchStatus.IN_PROGRESS && it.item.isTmdb && it.item.key !in favKeys }
            .maxByOrNull { it.updatedAt }?.item?.key
        return HomeSig(s.prefs.interests, s.prefs.favoriteGenres, s.prefs.excludedGenres, favKeys, active)
    }

    private fun rebuildHome(@Suppress("UNUSED_PARAMETER") signature: HomeSig) {
        val s = store.state.value
        val old = _rows.value.keys.filter {
            it.startsWith("d_") || it.startsWith("interest_") || it.startsWith("fav_") || it.startsWith("act_")
        }
        removeRows(old)
        val discover = reco.discoverRows(s.prefs)
        val interest = reco.interestRows(s.prefs, s.favorites, s.tracked)
        for (spec in discover + interest) ensureRow(spec.id, spec.title, spec.fetch)
        _discoverIds.value = discover.map { it.id }
        _interestIds.value = interest.map { it.id }
    }

    // ---------- Filas ----------
    fun ensureRow(id: String, title: String, fetch: suspend (Int) -> ApiResult<Page>) {
        if (_rows.value.containsKey(id)) return
        fetchers[id] = fetch
        gens[id] = (gens[id] ?: 0) + 1
        _rows.update { it + (id to RowState(id, title)) }
        loadNext(id)
    }

    private fun removeRows(ids: List<String>) {
        if (ids.isEmpty()) return
        for (id in ids) {
            fetchers.remove(id)
            gens[id] = (gens[id] ?: 0) + 1
            loading.remove(id)
        }
        _rows.update { m -> m.filterKeys { it !in ids } }
    }

    fun loadNext(id: String) {
        val st = _rows.value[id] ?: return
        val fetch = fetchers[id] ?: return
        if (st.page >= st.totalPages || st.items.size >= MAX_ROW_ITEMS) return
        if (!loading.add(id)) return
        val gen = gens[id] ?: 0
        _rows.update { m ->
            val cur = m[id]
            if (cur == null) m
            else m + (id to cur.copy(status = if (cur.items.isEmpty()) RowStatus.LOADING else cur.status, error = null))
        }
        viewModelScope.launch {
            val res = fetch(st.page + 1)
            loading.remove(id)
            if ((gens[id] ?: 0) != gen) return@launch
            _rows.update { m ->
                val cur = m[id]
                if (cur == null) {
                    m
                } else when (res) {
                    is ApiResult.Ok -> {
                        val merged = (cur.items + res.value.items).distinctBy { it.key }.take(MAX_ROW_ITEMS)
                        m + (id to cur.copy(
                            items = merged,
                            page = cur.page + 1,
                            totalPages = res.value.totalPages,
                            status = if (merged.isEmpty()) RowStatus.EMPTY else RowStatus.READY,
                            error = null,
                        ))
                    }
                    is ApiResult.Err -> m + (id to cur.copy(
                        status = if (cur.items.isEmpty()) RowStatus.ERROR else cur.status,
                        error = res.message,
                    ))
                }
            }
            if (id.startsWith("d_") && _featured.value == null) {
                _featured.value = _rows.value[id]?.items?.firstOrNull { it.backdropPath != null }
            }
        }
    }

    /** Reintenta las filas con error (p. ej. al volver de configurar la red). */
    fun retryFailedRows() {
        for ((id, st) in _rows.value) {
            if (st.error != null) loadNext(id)
        }
    }

    fun ensureBrowse(section: Section): List<String> {
        val specs = reco.browseRows(section)
        for (spec in specs) ensureRow(spec.id, spec.title, spec.fetch)
        return specs.map { it.id }
    }

    // ---------- Destacado ----------
    fun onItemFocused(item: ContentItem) {
        featuredJob?.cancel()
        featuredJob = viewModelScope.launch {
            delay(250)
            _featured.value = item
        }
    }

    // ---------- Fichas ----------
    fun loadDetail(item: ContentItem) {
        if (!item.isTmdb) return
        val existing = _details.value[item.key]
        if (existing != null && !existing.loading && existing.error == null) {
            ensureRelated(item)
            return
        }
        putDetail(item.key, DetailState(loading = true))
        ensureRelated(item)
        viewModelScope.launch {
            val d = async { tmdb.details(item) }
            val p = async { tmdb.providers(item) }
            val dr = d.await()
            val pr = p.await()
            putDetail(
                item.key,
                DetailState(
                    loading = false,
                    details = (dr as? ApiResult.Ok)?.value,
                    error = (dr as? ApiResult.Err)?.message,
                    providers = (pr as? ApiResult.Ok)?.value,
                    providersError = (pr as? ApiResult.Err)?.message,
                ),
            )
        }
    }

    private fun putDetail(key: String, state: DetailState) {
        _details.update { m ->
            val next = m + (key to state)
            if (next.size > 12) next.entries.drop(next.size - 12).associate { it.key to it.value } else next
        }
    }

    private fun ensureRelated(item: ContentItem) {
        val id = "rel_${item.key}"
        if (!relatedOrder.contains(id)) {
            relatedOrder.add(id)
            while (relatedOrder.size > 6) {
                val drop = relatedOrder.removeAt(0)
                removeRows(listOf(drop))
            }
        }
        val excluded = Genres.allIds(store.state.value.prefs.excludedGenres)
        ensureRow(id, "Relacionados") { p -> tmdb.recommendations(item, p).filtered(excluded) }
    }

    // ---------- Búsqueda ----------
    fun search(raw: String) {
        val q = raw.trim()
        if (q.length < 2) return
        searchJob?.cancel()
        _search.value = SearchUi(
            query = q,
            tmdbStatus = if (AppConfig.tmdbConfigured) LoadStatus.LOADING else LoadStatus.NOT_CONFIGURED,
            ytStatus = if (AppConfig.youtubeConfigured) LoadStatus.LOADING else LoadStatus.NOT_CONFIGURED,
        )
        searchJob = viewModelScope.launch {
            if (AppConfig.tmdbConfigured) {
                launch {
                    val r = tmdb.search(q)
                    if (_search.value.query == q) {
                        _search.update {
                            when (r) {
                                is ApiResult.Ok -> it.copy(
                                    tmdbStatus = LoadStatus.READY,
                                    tmdbItems = r.value.items,
                                    tmdbError = null,
                                )
                                is ApiResult.Err -> it.copy(tmdbStatus = LoadStatus.ERROR, tmdbError = r.message)
                            }
                        }
                    }
                }
            }
            if (AppConfig.youtubeConfigured) {
                launch {
                    val v = youtube.searchVideos(q)
                    val c = youtube.searchChannels(q)
                    if (_search.value.query == q) {
                        _search.update {
                            val videos = (v as? ApiResult.Ok)?.value ?: emptyList()
                            val channels = (c as? ApiResult.Ok)?.value ?: emptyList()
                            val error = if (v is ApiResult.Err && c is ApiResult.Err) v.message else null
                            it.copy(
                                ytStatus = if (error != null) LoadStatus.ERROR else LoadStatus.READY,
                                ytVideos = videos,
                                ytChannels = channels,
                                ytError = error,
                            )
                        }
                    }
                }
            }
        }
    }

    // ---------- Actividad de JullTV ----------
    fun onOpenedFromJull(item: ContentItem, packageName: String?) {
        store.recordOpened(item, packageName)
        pendingOpen = item.key to packageName
    }

    /** Al volver al launcher se registra el regreso; no demuestra que se haya visto algo. */
    fun onLauncherResumed() {
        val p = pendingOpen ?: return
        pendingOpen = null
        store.recordReturn(p.first, p.second)
    }
}
