package com.jull.tv.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.R
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Images
import com.jull.tv.catalog.Section
import com.jull.tv.config.AppConfig
import com.jull.tv.data.InstalledApp
import com.jull.tv.integration.Integrations
import com.jull.tv.local.WatchStatus
import com.jull.tv.ui.theme.JullColors
import com.jull.tv.util.AppLauncher

@Composable
fun CinematicBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            Brush.verticalGradient(listOf(Color(0xFF07151B), JullColors.Background)),
        )
        val center = Offset(size.width * 0.85f, size.height * 0.1f)
        val radius = size.width * 0.6f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(JullColors.Turquoise.copy(alpha = 0.16f), Color.Transparent),
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )
    }
}

/** Fondo base del destacado: composición turquesa de la v0.1 (se ve si no hay imagen). */
@Composable
private fun HeroBase() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            Brush.linearGradient(
                colors = listOf(Color(0xFF0B4A4A), Color(0xFF071014)),
                start = Offset.Zero,
                end = Offset(size.width, size.height),
            ),
        )
        val c = Offset(size.width * 0.82f, size.height * 0.5f)
        val glow = size.height * 1.4f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(JullColors.Turquoise.copy(alpha = 0.35f), Color.Transparent),
                center = c,
                radius = glow,
            ),
            radius = glow,
            center = c,
        )
        for (i in 1..4) {
            drawCircle(
                color = JullColors.Turquoise.copy(alpha = 0.12f),
                radius = size.height * 0.28f * i,
                center = c,
                style = Stroke(width = 2.dp.toPx()),
            )
        }
        val s = size.height * 0.3f
        val play = Path().apply {
            moveTo(c.x - s * 0.35f, c.y - s * 0.5f)
            lineTo(c.x + s * 0.55f, c.y)
            lineTo(c.x - s * 0.35f, c.y + s * 0.5f)
            close()
        }
        drawPath(play, JullColors.Turquoise.copy(alpha = 0.25f))
    }
}

/** Destacado: imagen panorámica real del título enfocado, con degradado oscuro para legibilidad. */
@Composable
private fun Hero(item: ContentItem?, tmdbMissing: Boolean, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(24.dp)
    val url = remember(item) { item?.let { Images.backdrop(it.backdropPath, "w780") } }
    Box(modifier = modifier.clip(shape)) {
        HeroBase()
        Crossfade(targetState = url, animationSpec = tween(400), label = "heroImage") { u ->
            if (u != null) RemoteImage(u, Modifier.fillMaxSize(), ContentScale.Crop)
        }
        if (url != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent))),
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)))),
            )
        } else {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent))),
            )
        }
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 32.dp),
        ) {
            if (item != null) {
                Text(
                    text = item.kind.label.uppercase(),
                    color = JullColors.Turquoise,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = item.title,
                    color = JullColors.TextPrimary,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth(0.6f),
                )
                val sub = item.overview ?: item.channelTitle
                if (sub != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = sub,
                        color = JullColors.TextSecondary,
                        fontSize = 17.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth(0.55f),
                    )
                }
            } else {
                Text(
                    text = stringResource(R.string.tagline),
                    color = JullColors.TextPrimary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 40.sp,
                    modifier = Modifier.fillMaxWidth(0.62f),
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (tmdbMissing) {
                        "Configura TMDB en Ajustes para ver recomendaciones de películas, series y anime."
                    } else {
                        stringResource(R.string.tagline_sub)
                    },
                    color = JullColors.TextSecondary,
                    fontSize = 19.sp,
                    modifier = Modifier.fillMaxWidth(0.55f),
                )
            }
        }
    }
}

@Composable
fun EmptyState(failed: Boolean, onRetry: () -> Unit, retryFocus: FocusRequester, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = stringResource(R.string.no_apps_title),
            color = JullColors.TextPrimary,
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = stringResource(if (failed) R.string.apps_error_body else R.string.no_apps_body),
            color = JullColors.TextSecondary,
            fontSize = 20.sp,
        )
        Spacer(Modifier.height(6.dp))
        TvButton(
            text = stringResource(R.string.retry),
            onClick = onRetry,
            modifier = Modifier.focusRequester(retryFocus),
        )
    }
}

private class ExploreEntry(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val action: () -> Unit,
)

@Composable
fun HomeScreen(
    nav: HomeViewModel,
    catalog: CatalogViewModel,
    appsState: AppsUiState,
    onOpenApp: (InstalledApp) -> Unit,
    onRetryApps: () -> Unit,
) {
    val context = LocalContext.current
    val rows by catalog.rows.collectAsStateWithLifecycle()
    val discoverIds by catalog.discoverIds.collectAsStateWithLifecycle()
    val interestIds by catalog.interestIds.collectAsStateWithLifecycle()
    val store by catalog.storeState.collectAsStateWithLifecycle()
    val featured by catalog.featured.collectAsStateWithLifecycle()

    val tvApps = remember(appsState.apps) { appsState.apps.filter { it.isTv } }
    // Si no hay apps de TV, se muestran las demás para no dejar la fila vacía.
    val homeApps = if (tvApps.isNotEmpty()) tvApps else appsState.apps
    val firstFocus = rememberScreenFocus(nav.focus, ready = !appsState.loading || homeApps.isNotEmpty())
    val continueItems = remember(store.tracked) {
        store.tracked.filter { it.status != WatchStatus.FINISHED }.sortedByDescending { it.updatedAt }.take(20)
    }
    val openItem: (ContentItem) -> Unit = { nav.push(Screen.Detail(it)) }

    val explore = listOf(
        ExploreEntry("movies", "Películas", Icons.Filled.PlayArrow) { nav.push(Screen.Browse(Section.MOVIES)) },
        ExploreEntry("series", "Series", Icons.Filled.List) { nav.push(Screen.Browse(Section.SERIES)) },
        ExploreEntry("anime", "Anime", Icons.Filled.Star) { nav.push(Screen.Browse(Section.ANIME)) },
        ExploreEntry("youtube", "YouTube", Icons.Filled.ThumbUp) { nav.push(Screen.Browse(Section.YOUTUBE)) },
        ExploreEntry("search", "Buscar", Icons.Filled.Search) { nav.push(Screen.Search) },
        ExploreEntry("tracking", "Seguimiento", Icons.Filled.Check) { nav.push(Screen.Tracking) },
        ExploreEntry("interests", "Mis intereses", Icons.Filled.Favorite) { nav.push(Screen.Interests) },
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 48.dp, vertical = 27.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.app_name),
                    color = JullColors.Turquoise,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.width(14.dp))
                Text(
                    text = stringResource(R.string.tagline),
                    color = JullColors.TextSecondary,
                    fontSize = 18.sp,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                ClockText()
                Spacer(Modifier.width(20.dp))
                SettingsButton(onClick = { nav.push(Screen.Settings) })
            }
        }

        Spacer(Modifier.height(12.dp))
        Hero(
            item = featured,
            tmdbMissing = !AppConfig.tmdbConfigured,
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp),
        )
        Spacer(Modifier.height(6.dp))

        LazyColumn(
            state = nav.listState("home"),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 40.dp),
        ) {
            // ----- Aplicaciones (v0.1) -----
            item(key = "apps") {
                Column {
                    SectionTitle(stringResource(R.string.my_apps))
                    when {
                        appsState.loading && homeApps.isEmpty() -> {
                            InfoText(stringResource(R.string.loading), Modifier.padding(vertical = 14.dp))
                        }
                        homeApps.isEmpty() -> {
                            EmptyState(
                                failed = appsState.failed,
                                onRetry = onRetryApps,
                                retryFocus = firstFocus,
                                modifier = Modifier.padding(vertical = 12.dp),
                            )
                        }
                        else -> {
                            LazyRow(
                                state = nav.listState("home_apps"),
                                horizontalArrangement = Arrangement.spacedBy(20.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                itemsIndexed(homeApps, key = { _, a -> a.key }) { index, app ->
                                    AppCard(
                                        app = app,
                                        onClick = { onOpenApp(app) },
                                        modifier = Modifier.trackFocus(
                                            key = "app:${app.key}",
                                            memory = nav.focus,
                                            first = if (index == 0) firstFocus else null,
                                        ),
                                    )
                                }
                                item(key = "all_apps") {
                                    ActionCard(
                                        label = stringResource(R.string.all_apps),
                                        icon = Icons.Filled.Menu,
                                        onClick = { nav.push(Screen.AllApps) },
                                        modifier = Modifier.trackFocus("action:all_apps", nav.focus),
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ----- Continuar viendo (historial local de JullTV) -----
            item(key = "continue") {
                Column {
                    SectionTitle("Continuar viendo")
                    if (continueItems.isEmpty()) {
                        InfoText(
                            "Aún no hay títulos en seguimiento. Abre la ficha de un título y añádelo.",
                            Modifier.padding(vertical = 10.dp),
                        )
                    } else {
                        LazyRow(
                            state = nav.listState("home_continue"),
                            horizontalArrangement = Arrangement.spacedBy(20.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            items(continueItems, key = { it.item.key }) { t ->
                                ContentCard(
                                    item = t.item,
                                    onClick = { openItem(t.item) },
                                    modifier = Modifier.trackFocus("cont:${t.item.key}", nav.focus),
                                    onFocus = { catalog.onItemFocused(t.item) },
                                    progress = t.progressPercent?.let { it / 100f },
                                    caption = t.caption(),
                                )
                            }
                            item(key = "all_tracked") {
                                ActionCard(
                                    label = "Ver todo",
                                    icon = Icons.Filled.List,
                                    onClick = { nav.push(Screen.Tracking) },
                                    modifier = Modifier.trackFocus("action:all_tracked", nav.focus),
                                )
                            }
                        }
                    }
                }
            }

            // ----- Explorar -----
            item(key = "explore") {
                Column {
                    SectionTitle("Explorar")
                    LazyRow(
                        state = nav.listState("home_explore"),
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        items(explore, key = { it.id }) { e ->
                            ActionCard(
                                label = e.label,
                                icon = e.icon,
                                onClick = e.action,
                                modifier = Modifier.trackFocus("explore:${e.id}", nav.focus),
                            )
                        }
                    }
                }
            }

            // ----- Catálogo no configurado -----
            if (!AppConfig.tmdbConfigured) {
                item(key = "tmdb_missing") {
                    Column(Modifier.padding(vertical = 8.dp)) {
                        SectionTitle("Catálogo de películas, series y anime")
                        InfoText(
                            "TMDB no está configurado, por eso no hay recomendaciones. " +
                                "El launcher y tus aplicaciones funcionan con normalidad.",
                            Modifier.padding(vertical = 6.dp),
                        )
                        TvButton(
                            text = "Cómo configurarlo",
                            onClick = { nav.push(Screen.Settings) },
                            modifier = Modifier.trackFocus("action:tmdb_help", nav.focus),
                        )
                    }
                }
            }

            // ----- Para descubrir -----
            items(discoverIds, key = { it }) { id ->
                ContentRow(
                    rowId = id,
                    state = rows[id],
                    nav = nav,
                    catalog = catalog,
                    onOpen = openItem,
                )
            }

            if (!AppConfig.youtubeConfigured) {
                item(key = "yt_fallback") {
                    Column {
                        SectionTitle("YouTube")
                        LazyRow(
                            state = nav.listState("home_yt"),
                            horizontalArrangement = Arrangement.spacedBy(20.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            item(key = "yt_search") {
                                ActionCard(
                                    label = "Buscar en YouTube",
                                    icon = Icons.Filled.Search,
                                    onClick = { nav.push(Screen.Search) },
                                    modifier = Modifier.trackFocus("action:yt_search", nav.focus),
                                )
                            }
                            item(key = "yt_open") {
                                ActionCard(
                                    label = "Abrir YouTube",
                                    icon = Icons.Filled.ThumbUp,
                                    onClick = {
                                        val app = appsState.apps.firstOrNull { Integrations.isYouTube(it) }
                                        if (app != null) onOpenApp(app)
                                        else AppLauncher.openUrl(context, "https://www.youtube.com")
                                    },
                                    modifier = Modifier.trackFocus("action:yt_open", nav.focus),
                                )
                            }
                        }
                    }
                }
            }

            // ----- Según tus intereses -----
            items(interestIds, key = { it }) { id ->
                ContentRow(
                    rowId = id,
                    state = rows[id],
                    nav = nav,
                    catalog = catalog,
                    onOpen = openItem,
                )
            }
        }
    }
}
