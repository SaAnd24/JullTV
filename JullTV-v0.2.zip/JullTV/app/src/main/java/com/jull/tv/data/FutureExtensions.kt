package com.jull.tv.data

/*
 * Puntos de extensión para versiones futuras. En la v0.1 NO se usan ni
 * devuelven datos: no hay servicios externos ni historial ficticio.
 * Nunca se asume acceso al historial privado de otras aplicaciones.
 */

data class FeaturedItem(
    val id: String,
    val title: String,
    val subtitle: String? = null,
    val backgroundUrl: String? = null,
)

/** Contenido destacado / recomendaciones y fondos dinámicos (futuro). */
interface FeaturedRepository {
    suspend fun featured(): List<FeaturedItem>
}

data class WatchProgress(
    val contentId: String,
    val title: String,
    val progressPercent: Int,
    val sourcePackage: String?,
    val updatedAtMillis: Long,
    /** true si el usuario registró el progreso a mano. */
    val isManual: Boolean,
)

/** «Continuar viendo»: seguimiento local y manual (futuro). */
interface ContinueWatchingRepository {
    suspend fun items(): List<WatchProgress>
}

object EmptyFeaturedRepository : FeaturedRepository {
    override suspend fun featured(): List<FeaturedItem> = emptyList()
}

object EmptyContinueWatchingRepository : ContinueWatchingRepository {
    override suspend fun items(): List<WatchProgress> = emptyList()
}
