package com.jull.tv.ui

import android.app.Application
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jull.tv.data.AppRepository
import com.jull.tv.data.InstalledApp
import com.jull.tv.util.AppLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@Immutable
data class AppsUiState(
    val loading: Boolean = true,
    val apps: List<InstalledApp> = emptyList(),
    val failed: Boolean = false,
)

/** Aplicaciones instaladas (v0.1) + navegación entre pantallas y memoria de foco/desplazamiento. */
class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val _state = MutableStateFlow(AppsUiState())
    val state: StateFlow<AppsUiState> = _state.asStateFlow()

    private var job: Job? = null

    fun refresh() {
        job?.cancel()
        job = viewModelScope.launch {
            try {
                val apps = repository.loadApps()
                _state.value = AppsUiState(loading = false, apps = apps)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                AppLog.e("Fallo al cargar aplicaciones", e)
                _state.value = AppsUiState(loading = false, apps = emptyList(), failed = true)
            }
        }
    }

    // ---------- Navegación ----------
    val focus = FocusMemory()
    val backStack = mutableStateListOf<Screen>(Screen.Home)
    private val restoreStack = ArrayList<String?>()
    private val listStates = HashMap<String, LazyListState>()

    val current: Screen get() = backStack.last()

    /** Estado de desplazamiento conservado entre pantallas (clave por lista). */
    fun listState(id: String): LazyListState = listStates.getOrPut(id) { LazyListState() }

    fun push(screen: Screen) {
        restoreStack.add(focus.lastKey)
        backStack.add(screen)
    }

    /** Vuelve a la pantalla anterior. Devuelve false si ya se está en el inicio. */
    fun pop(): Boolean {
        if (backStack.size <= 1) return false
        backStack.removeAt(backStack.lastIndex)
        focus.restoreKey = if (restoreStack.isNotEmpty()) restoreStack.removeAt(restoreStack.lastIndex) else null
        return true
    }

    fun goHome() {
        backStack.clear()
        backStack.add(Screen.Home)
        restoreStack.clear()
        focus.restoreKey = null
    }
}
