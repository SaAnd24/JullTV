package com.jull.tv

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import java.io.File

/** Configura la caché de imágenes (limitada para televisores con pocos recursos). */
class JullApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader {
        val app = this@JullApp
        return ImageLoader.Builder(app)
            .memoryCache { MemoryCache.Builder(app).maxSizePercent(0.15).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(app.cacheDir, "image_cache"))
                    .maxSizeBytes(50L * 1024 * 1024)
                    .build()
            }
            .respectCacheHeaders(false)
            .allowRgb565(true)
            .crossfade(true)
            .build()
    }
}
