package com.jull.tv.util

import android.util.Log

/** Registro centralizado. Filtra en logcat con: adb logcat -s JullTV */
object AppLog {
    const val TAG = "JullTV"

    fun d(message: String) {
        Log.d(TAG, message)
    }

    fun w(message: String, throwable: Throwable? = null) {
        Log.w(TAG, message, throwable)
    }

    fun e(message: String, throwable: Throwable? = null) {
        Log.e(TAG, message, throwable)
    }
}
