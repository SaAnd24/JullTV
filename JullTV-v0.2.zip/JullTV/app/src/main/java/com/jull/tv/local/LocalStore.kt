package com.jull.tv.local

import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Kind
import com.jull.tv.net.doubleOrNull
import com.jull.tv.net.intOrNull
import com.jull.tv.net.ints
import com.jull.tv.net.longOrNull
import com.jull.tv.net.objects
import com.jull.tv.net.strOrNull
import com.jull.tv.net.strings
import com.jull.tv.util.AppLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persistencia local en un único archivo JSON dentro del almacenamiento privado de la app.
 * Nada sale del dispositivo. Todas las operaciones de disco se hacen fuera del hilo principal.
 */
class LocalStore(private val file: File, private val scope: CoroutineScope) {

    private val _state = MutableStateFlow(StoreState())
    val state: StateFlow<StoreState> = _state.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val mutex = Mutex()

    fun load() {
        scope.launch { mutex.withLock { ensureLoaded() } }
    }

    private suspend fun ensureLoaded() {
        if (_loaded.value) return
        _state.value = withContext(Dispatchers.IO) { read() }
        _loaded.value = true
    }

    private fun mutate(block: (StoreState) -> StoreState) {
        scope.launch {
            mutex.withLock {
                ensureLoaded()
                val next = block(_state.value)
                _state.value = next
                withContext(Dispatchers.IO) { write(next) }
            }
        }
    }

    // ---------- Favoritos ----------
    fun toggleFavorite(item: ContentItem) = mutate { s ->
        val exists = s.favorites.any { it.key == item.key }
        s.copy(
            favorites = if (exists) s.favorites.filterNot { it.key == item.key }
            else (listOf(item) + s.favorites).take(100),
        )
    }

    fun clearFavorites() = mutate { it.copy(favorites = emptyList()) }

    // ---------- Seguimiento ----------
    fun track(item: ContentItem, status: WatchStatus) = mutate { s ->
        val now = System.currentTimeMillis()
        val existing = s.tracked.firstOrNull { it.item.key == item.key }
        val updated = existing?.copy(status = status, updatedAt = now)
            ?: TrackedItem(item, status, null, null, null, null, now, now, null, null)
        s.copy(
            tracked = (listOf(updated) + s.tracked.filterNot { it.item.key == item.key }).take(300),
            activity = addActivity(s.activity, item, "estado: ${status.label}", null, now),
        )
    }

    fun remove(key: String) = mutate { s -> s.copy(tracked = s.tracked.filterNot { it.item.key == key }) }

    fun setPercent(key: String, percent: Int?) = modify(key) { it.copy(progressPercent = percent) }
    fun setSeason(key: String, season: Int?) = modify(key) { it.copy(season = season) }
    fun setEpisode(key: String, episode: Int?) = modify(key) { it.copy(episode = episode) }

    private fun modify(key: String, change: (TrackedItem) -> TrackedItem) = mutate { s ->
        val now = System.currentTimeMillis()
        s.copy(
            tracked = s.tracked.map { t ->
                if (t.item.key != key) t else {
                    var n = change(t).copy(updatedAt = now)
                    val hasProgress = n.progressPercent != null || n.season != null || n.episode != null
                    if (n.status == WatchStatus.PENDING && hasProgress) n = n.copy(status = WatchStatus.IN_PROGRESS)
                    n
                }
            },
        )
    }

    fun clearTracked() = mutate { it.copy(tracked = emptyList()) }

    // ---------- Actividad de JullTV (no prueba reproducción) ----------
    fun recordOpened(item: ContentItem, pkg: String?) = mutate { s ->
        val now = System.currentTimeMillis()
        s.copy(
            tracked = s.tracked.map {
                if (it.item.key == item.key) it.copy(sourcePackage = pkg ?: it.sourcePackage, lastOpenedAt = now) else it
            },
            activity = addActivity(s.activity, item, "abierto desde JullTV", pkg, now),
        )
    }

    fun recordReturn(key: String, pkg: String?) = mutate { s ->
        val now = System.currentTimeMillis()
        val t = s.tracked.firstOrNull { it.item.key == key }
        s.copy(
            tracked = s.tracked.map { if (it.item.key == key) it.copy(lastReturnAt = now) else it },
            activity = (listOf(
                ActivityEntry(key, t?.item?.title ?: key, "regreso al launcher", now, pkg),
            ) + s.activity).take(100),
        )
    }

    fun clearActivity() = mutate { it.copy(activity = emptyList()) }

    private fun addActivity(
        list: List<ActivityEntry>,
        item: ContentItem,
        type: String,
        pkg: String?,
        now: Long,
    ): List<ActivityEntry> = (listOf(ActivityEntry(item.key, item.title, type, now, pkg)) + list).take(100)

    // ---------- Preferencias ----------
    fun toggleInterest(interest: Interest) = mutate { s ->
        val set = s.prefs.interests.toMutableSet()
        if (!set.add(interest)) set.remove(interest)
        s.copy(prefs = s.prefs.copy(interests = set))
    }

    fun toggleFavoriteGenre(id: String) = mutate { s ->
        val fav = s.prefs.favoriteGenres.toMutableSet()
        val exc = s.prefs.excludedGenres.toMutableSet()
        if (!fav.add(id)) fav.remove(id) else exc.remove(id)
        s.copy(prefs = s.prefs.copy(favoriteGenres = fav, excludedGenres = exc))
    }

    fun toggleExcludedGenre(id: String) = mutate { s ->
        val fav = s.prefs.favoriteGenres.toMutableSet()
        val exc = s.prefs.excludedGenres.toMutableSet()
        if (!exc.add(id)) exc.remove(id) else fav.remove(id)
        s.copy(prefs = s.prefs.copy(favoriteGenres = fav, excludedGenres = exc))
    }

    // ---------- Disco ----------
    private fun read(): StoreState {
        if (!file.exists()) return StoreState()
        return try {
            val root = JSONObject(file.readText())
            val prefsJson = root.optJSONObject("prefs")
            val prefs = if (prefsJson == null) UserPrefs() else UserPrefs(
                interests = prefsJson.optJSONArray("interests").strings()
                    .mapNotNull { n -> Interest.values().firstOrNull { it.name == n } }.toSet(),
                favoriteGenres = prefsJson.optJSONArray("favoriteGenres").strings().toSet(),
                excludedGenres = prefsJson.optJSONArray("excludedGenres").strings().toSet(),
            )
            StoreState(
                prefs = prefs,
                favorites = root.optJSONArray("favorites").objects().mapNotNull { itemFromJson(it) },
                tracked = root.optJSONArray("tracked").objects().mapNotNull { trackedFromJson(it) },
                activity = root.optJSONArray("activity").objects().mapNotNull { activityFromJson(it) },
            )
        } catch (e: Exception) {
            AppLog.e("No se pudo leer el estado local; se empieza vacío", e)
            StoreState()
        }
    }

    private fun write(s: StoreState) {
        try {
            val root = JSONObject()
            root.put("version", 1)
            root.put(
                "prefs",
                JSONObject()
                    .put("interests", JSONArray(s.prefs.interests.map { it.name }))
                    .put("favoriteGenres", JSONArray(s.prefs.favoriteGenres.toList()))
                    .put("excludedGenres", JSONArray(s.prefs.excludedGenres.toList())),
            )
            root.put("favorites", JSONArray().also { a -> s.favorites.forEach { a.put(itemToJson(it)) } })
            root.put("tracked", JSONArray().also { a -> s.tracked.forEach { a.put(trackedToJson(it)) } })
            root.put("activity", JSONArray().also { a -> s.activity.forEach { a.put(activityToJson(it)) } })
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(root.toString())
                tmp.delete()
            }
        } catch (e: Exception) {
            AppLog.e("No se pudo guardar el estado local", e)
        }
    }

    private fun itemToJson(i: ContentItem): JSONObject {
        val o = JSONObject()
        o.put("key", i.key)
        o.put("kind", i.kind.name)
        o.put("title", i.title)
        i.overview?.let { o.put("overview", it) }
        i.posterPath?.let { o.put("posterPath", it) }
        i.backdropPath?.let { o.put("backdropPath", it) }
        i.date?.let { o.put("date", it) }
        i.rating?.let { o.put("rating", it) }
        o.put("genreIds", JSONArray(i.genreIds))
        i.channelTitle?.let { o.put("channelTitle", it) }
        return o
    }

    private fun itemFromJson(o: JSONObject): ContentItem? {
        val key = o.strOrNull("key") ?: return null
        val kind = Kind.values().firstOrNull { it.name == o.optString("kind", "") } ?: return null
        val title = o.strOrNull("title") ?: return null
        return ContentItem(
            key = key,
            kind = kind,
            title = title,
            overview = o.strOrNull("overview"),
            posterPath = o.strOrNull("posterPath"),
            backdropPath = o.strOrNull("backdropPath"),
            date = o.strOrNull("date"),
            rating = o.doubleOrNull("rating"),
            genreIds = o.optJSONArray("genreIds").ints(),
            channelTitle = o.strOrNull("channelTitle"),
        )
    }

    private fun trackedToJson(t: TrackedItem): JSONObject {
        val o = JSONObject()
        o.put("item", itemToJson(t.item))
        o.put("status", t.status.name)
        t.progressPercent?.let { o.put("progress", it) }
        t.season?.let { o.put("season", it) }
        t.episode?.let { o.put("episode", it) }
        t.sourcePackage?.let { o.put("source", it) }
        o.put("createdAt", t.createdAt)
        o.put("updatedAt", t.updatedAt)
        t.lastOpenedAt?.let { o.put("lastOpenedAt", it) }
        t.lastReturnAt?.let { o.put("lastReturnAt", it) }
        return o
    }

    private fun trackedFromJson(o: JSONObject): TrackedItem? {
        val item = o.optJSONObject("item")?.let { itemFromJson(it) } ?: return null
        val status = WatchStatus.values().firstOrNull { it.name == o.optString("status", "") } ?: WatchStatus.PENDING
        val now = System.currentTimeMillis()
        return TrackedItem(
            item = item,
            status = status,
            progressPercent = o.intOrNull("progress"),
            season = o.intOrNull("season"),
            episode = o.intOrNull("episode"),
            sourcePackage = o.strOrNull("source"),
            createdAt = o.longOrNull("createdAt") ?: now,
            updatedAt = o.longOrNull("updatedAt") ?: now,
            lastOpenedAt = o.longOrNull("lastOpenedAt"),
            lastReturnAt = o.longOrNull("lastReturnAt"),
        )
    }

    private fun activityToJson(a: ActivityEntry): JSONObject {
        val o = JSONObject()
        o.put("key", a.key)
        o.put("title", a.title)
        o.put("type", a.type)
        o.put("at", a.atMillis)
        a.packageName?.let { o.put("pkg", it) }
        return o
    }

    private fun activityFromJson(o: JSONObject): ActivityEntry? {
        val key = o.strOrNull("key") ?: return null
        return ActivityEntry(
            key = key,
            title = o.strOrNull("title") ?: key,
            type = o.strOrNull("type") ?: "",
            atMillis = o.longOrNull("at") ?: 0L,
            packageName = o.strOrNull("pkg"),
        )
    }
}
