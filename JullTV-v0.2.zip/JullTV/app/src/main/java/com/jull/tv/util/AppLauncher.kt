package com.jull.tv.util

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import com.jull.tv.R
import com.jull.tv.data.InstalledApp

object AppLauncher {

    /** Abre la aplicación indicada. Nunca lanza excepciones; muestra un aviso si falla. */
    fun launch(context: Context, app: InstalledApp): Boolean {
        val category = if (app.isTv) Intent.CATEGORY_LEANBACK_LAUNCHER else Intent.CATEGORY_LAUNCHER
        val direct = Intent(Intent.ACTION_MAIN).apply {
            addCategory(category)
            component = ComponentName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        if (tryStart(context, direct, app.key)) return true

        val pm = context.packageManager
        val fallback = pm.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: pm.getLaunchIntentForPackage(app.packageName)
        if (fallback != null) {
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (tryStart(context, fallback, app.packageName)) return true
        }

        Toast.makeText(context, context.getString(R.string.cannot_open, app.label), Toast.LENGTH_LONG).show()
        return false
    }

    /** Abre un enlace oficial (YouTube, etc.). Prefiere la app indicada y cae al sistema si no puede. */
    fun openUrl(context: Context, url: String, preferredPackage: String? = null): Boolean {
        val uri = Uri.parse(url)
        if (preferredPackage != null) {
            val targeted = Intent(Intent.ACTION_VIEW, uri)
                .setPackage(preferredPackage)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (tryStart(context, targeted, url)) return true
        }
        val generic = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (tryStart(context, generic, url)) return true
        Toast.makeText(context, "No se encontró una aplicación para abrir este enlace", Toast.LENGTH_LONG).show()
        return false
    }

    fun openSystemSettings(context: Context) {
        val intent = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!tryStart(context, intent, "ajustes")) {
            Toast.makeText(context, R.string.cannot_open_settings, Toast.LENGTH_LONG).show()
        }
    }

    private fun tryStart(context: Context, intent: Intent, what: String): Boolean {
        return try {
            context.startActivity(intent)
            AppLog.d("Abierto: $what")
            true
        } catch (e: ActivityNotFoundException) {
            AppLog.e("Actividad no encontrada para $what", e)
            false
        } catch (e: SecurityException) {
            AppLog.e("Sin permiso para abrir $what", e)
            false
        } catch (e: Exception) {
            AppLog.e("Error inesperado al abrir $what", e)
            false
        }
    }
}
