package com.jull.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.config.AppConfig
import com.jull.tv.integration.Integrations
import com.jull.tv.net.Connectivity
import com.jull.tv.util.AppLauncher

@Composable
private fun ConfirmButton(label: String, armed: Boolean, onArm: () -> Unit, onConfirm: () -> Unit) {
    TvButton(
        text = if (armed) "Pulsa otra vez para confirmar" else label,
        onClick = { if (armed) onConfirm() else onArm() },
    )
}

@Composable
fun SettingsScreen(nav: HomeViewModel, catalog: CatalogViewModel, appsState: AppsUiState) {
    val context = LocalContext.current
    val store by catalog.storeState.collectAsStateWithLifecycle()
    var online by remember { mutableStateOf(Connectivity.isOnline(context)) }
    var armed by remember { mutableStateOf<String?>(null) }
    val first = rememberScreenFocus(nav.focus)

    val apps = appsState.apps
    val pinned = apps.filter { Integrations.isPinned(it) }

    ScreenScaffold(title = "Ajustes y diagnóstico", subtitle = "JullTV ${AppConfig.version}") {
        LazyColumn(
            state = nav.listState("settings"),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item(key = "net") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle("Conexión")
                    InfoText(
                        if (online) "Conectado a internet."
                        else "Sin conexión. Las aplicaciones y tu historial local siguen disponibles.",
                    )
                    TvButton(
                        text = "Comprobar de nuevo",
                        onClick = {
                            online = Connectivity.isOnline(context)
                            catalog.retryFailedRows()
                        },
                        modifier = Modifier.focusRequester(first),
                    )
                }
            }

            item(key = "tmdb") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle("Catálogo: TMDB")
                    if (AppConfig.tmdbConfigured) {
                        InfoText("Configurado. Películas, series, anime, fichas y proveedores disponibles.")
                    } else {
                        InfoText("No configurado. El launcher funciona, pero no hay catálogo ni recomendaciones.")
                        InfoText(
                            "Para activarlo: 1) crea una cuenta gratuita en themoviedb.org y pide una clave API; " +
                                "2) en GitHub abre Settings → Secrets and variables → Actions → New repository secret " +
                                "y crea TMDB_API_KEY con tu clave; 3) ejecuta de nuevo «Build debug APK» e instala el " +
                                "nuevo APK. Los pasos detallados están en el README.",
                        )
                    }
                }
            }

            item(key = "yt") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle("YouTube Data API (opcional)")
                    if (AppConfig.youtubeConfigured) {
                        InfoText("Configurada. Vídeos populares y búsqueda de vídeos y canales (cuota diaria limitada).")
                    } else {
                        InfoText(
                            "No configurada. Puedes buscar con el buscador oficial de YouTube y abrir la aplicación. " +
                                "Para activarla crea el secreto YOUTUBE_API_KEY igual que TMDB_API_KEY.",
                        )
                    }
                    InfoText("JullTV no accede al historial ni a la cuenta de YouTube; solo usa datos públicos.")
                }
            }

            item(key = "apps") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle("Aplicaciones instaladas")
                    InfoText("${apps.size} detectadas (${apps.count { it.isTv }} de TV).")
                    TvButton(text = "Ver todas las aplicaciones", onClick = { nav.push(Screen.AllApps) })
                    TvButton(
                        text = "Ajustes del sistema (elegir launcher)",
                        onClick = { AppLauncher.openSystemSettings(context) },
                    )
                }
            }

            item(key = "integrations") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle("Integraciones por aplicación")
                    if (pinned.isEmpty()) {
                        InfoText("YouTube y Xuper TV no están instaladas o no se detectaron.")
                    }
                    for (app in pinned) {
                        InfoText("${app.label}: ${Integrations.statesFor(app).joinToString(" · ") { it.label }}")
                    }
                    InfoText(
                        "Las demás aplicaciones: detectadas y abribles, con seguimiento manual. " +
                            "Ninguna aplicación comparte su progreso con JullTV; no se leen datos privados de otras apps.",
                    )
                }
            }

            item(key = "local") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Seguimiento local")
                    InfoText(
                        "${store.tracked.size} títulos en seguimiento, ${store.favorites.size} favoritos, " +
                            "${store.activity.size} registros de actividad. Se guardan solo en este dispositivo.",
                    )
                    ConfirmButton("Borrar actividad", armed == "activity", { armed = "activity" }) {
                        catalog.store.clearActivity()
                        armed = null
                    }
                    ConfirmButton("Borrar seguimiento", armed == "tracked", { armed = "tracked" }) {
                        catalog.store.clearTracked()
                        armed = null
                    }
                    ConfirmButton("Borrar favoritos", armed == "favorites", { armed = "favorites" }) {
                        catalog.store.clearFavorites()
                        armed = null
                    }
                    TvButton(text = "Mis intereses", onClick = { nav.push(Screen.Interests) })
                }
            }

            item(key = "credits") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle("Atribuciones")
                    InfoText("This product uses the TMDB API but is not endorsed or certified by TMDB.")
                    InfoText("Este producto usa la API de TMDB pero no está respaldado ni certificado por TMDB.")
                    InfoText("Datos de proveedores de visualización: JustWatch (vía TMDB).")
                    InfoText("YouTube es una marca de Google LLC. JullTV usa YouTube Data API y enlaces oficiales.")
                }
            }
        }
    }
}
