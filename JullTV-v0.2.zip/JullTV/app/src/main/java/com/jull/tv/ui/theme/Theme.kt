package com.jull.tv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object JullColors {
    val Background = Color(0xFF05090D)
    val Surface = Color(0xFF0E161C)
    val SurfaceHigh = Color(0xFF16222A)
    val Turquoise = Color(0xFF2DD4BF)
    val TurquoiseDeep = Color(0xFF0F766E)
    val TextPrimary = Color(0xFFF2F7F8)
    val TextSecondary = Color(0xFF9FB3B8)
}

private val JullScheme = darkColorScheme(
    primary = JullColors.Turquoise,
    onPrimary = JullColors.Background,
    background = JullColors.Background,
    onBackground = JullColors.TextPrimary,
    surface = JullColors.Surface,
    onSurface = JullColors.TextPrimary,
)

@Composable
fun JullTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = JullScheme, content = content)
}
