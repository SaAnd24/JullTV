package com.jull.tv.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Section
import kotlinx.coroutines.delay

sealed interface Screen {
    object Home : Screen
    object AllApps : Screen
    data class Browse(val section: Section) : Screen
    object Search : Screen
    data class Detail(val item: ContentItem) : Screen
    object Interests : Screen
    object Tracking : Screen
    object Settings : Screen
}

/** Recuerda el último elemento enfocado para devolver el foco al volver desde otra pantalla. */
class FocusMemory {
    var lastKey: String? = null
    var restoreKey: String? by mutableStateOf(null)
}

/** Registra el foco de un elemento y, si le toca, lo recupera al volver a la pantalla. */
@Composable
fun Modifier.trackFocus(key: String, memory: FocusMemory, first: FocusRequester? = null): Modifier {
    val own = remember { FocusRequester() }
    val requester = first ?: own
    if (memory.restoreKey == key) {
        LaunchedEffect(key, memory.restoreKey) {
            delay(150)
            if (memory.restoreKey == key) {
                memory.restoreKey = null
                runCatching { requester.requestFocus() }
            }
        }
    }
    return this
        .focusRequester(requester)
        .onFocusChanged { if (it.isFocused) memory.lastKey = key }
}

/**
 * Devuelve el FocusRequester del primer elemento de una pantalla. Si se vuelve de otra pantalla,
 * espera a que se restaure el foco anterior y, si no pudo restaurarse, enfoca el primer elemento.
 */
@Composable
fun rememberScreenFocus(memory: FocusMemory, ready: Boolean = true): FocusRequester {
    val requester = remember { FocusRequester() }
    val hadRestore = remember { memory.restoreKey != null }
    LaunchedEffect(ready) {
        if (!ready) return@LaunchedEffect
        if (!hadRestore) {
            delay(250)
            runCatching { requester.requestFocus() }
        } else {
            delay(800)
            if (memory.restoreKey != null) {
                memory.restoreKey = null
                runCatching { requester.requestFocus() }
            }
        }
    }
    return requester
}
