package com.jull.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jull.tv.R
import com.jull.tv.data.InstalledApp
import com.jull.tv.ui.theme.JullColors
import kotlinx.coroutines.delay

@Composable
fun AllAppsScreen(
    state: AppsUiState,
    onOpenApp: (InstalledApp) -> Unit,
    onRetry: () -> Unit,
) {
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(state.loading, state.apps.size) {
        delay(200)
        runCatching { firstFocus.requestFocus() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 48.dp, vertical = 27.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text(
                    text = stringResource(R.string.all_apps),
                    color = JullColors.TextPrimary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = stringResource(R.string.all_apps_hint),
                    color = JullColors.TextSecondary,
                    fontSize = 18.sp,
                )
            }
            ClockText()
        }
        Spacer(Modifier.height(16.dp))

        when {
            state.loading && state.apps.isEmpty() -> {
                Text(
                    text = stringResource(R.string.loading),
                    color = JullColors.TextSecondary,
                    fontSize = 20.sp,
                )
            }
            state.apps.isEmpty() -> {
                EmptyState(failed = state.failed, onRetry = onRetry, retryFocus = firstFocus)
            }
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 200.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    itemsIndexed(state.apps, key = { _, app -> app.key }) { index, app ->
                        AppCard(
                            app = app,
                            onClick = { onOpenApp(app) },
                            modifier = if (index == 0) Modifier.focusRequester(firstFocus) else Modifier,
                        )
                    }
                }
            }
        }
    }
}
