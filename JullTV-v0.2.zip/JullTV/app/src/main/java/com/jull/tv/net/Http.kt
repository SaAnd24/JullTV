package com.jull.tv.net

import com.jull.tv.util.AppLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

sealed interface ApiResult<out T> {
    data class Ok<out T>(val value: T) : ApiResult<T>
    data class Err(val kind: ErrorKind, val message: String, val httpCode: Int? = null) : ApiResult<Nothing>
}

enum class ErrorKind { NOT_CONFIGURED, NETWORK, HTTP, QUOTA, PARSE }

inline fun <T, R> ApiResult<T>.map(transform: (T) -> R): ApiResult<R> = when (this) {
    is ApiResult.Ok -> ApiResult.Ok(transform(value))
    is ApiResult.Err -> this
}

/** Cliente HTTP mínimo con timeouts y caché en memoria con caducidad. Nunca se registran claves. */
object Http {
    private const val CONNECT_TIMEOUT_MS = 8_000
    private const val READ_TIMEOUT_MS = 12_000
    private const val MAX_CACHE_ENTRIES = 60

    private class Entry(val body: String, val at: Long)

    private val cache = object : LinkedHashMap<String, Entry>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>?): Boolean =
            size > MAX_CACHE_ENTRIES
    }

    suspend fun getJson(
        url: String,
        headers: Map<String, String> = emptyMap(),
        ttlMs: Long = 10 * 60_000L,
    ): ApiResult<JSONObject> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val cached = synchronized(cache) { cache[url] }
        if (cached != null && now - cached.at < ttlMs) {
            try {
                return@withContext ApiResult.Ok(JSONObject(cached.body))
            } catch (e: JSONException) {
                // caché dañada: se vuelve a pedir
            }
        }

        AppLog.d("GET " + redact(url))
        var conn: HttpURLConnection? = null
        val result: ApiResult<JSONObject> = try {
            val c = URL(url).openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = CONNECT_TIMEOUT_MS
            c.readTimeout = READ_TIMEOUT_MS
            c.requestMethod = "GET"
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("User-Agent", "JullTV/0.2")
            for ((k, v) in headers) c.setRequestProperty(k, v)

            val code = c.responseCode
            if (code in 200..299) {
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                synchronized(cache) { cache[url] = Entry(body, now) }
                ApiResult.Ok(json)
            } else {
                val errBody = try {
                    c.errorStream?.bufferedReader()?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
                httpError(code, errBody)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: JSONException) {
            AppLog.e("Respuesta no válida", e)
            ApiResult.Err(ErrorKind.PARSE, "Respuesta no válida del servicio")
        } catch (e: IOException) {
            AppLog.w("Error de red: ${e.javaClass.simpleName}")
            ApiResult.Err(ErrorKind.NETWORK, "Sin conexión o el servicio no responde")
        } catch (e: Exception) {
            AppLog.e("Error inesperado de red", e)
            ApiResult.Err(ErrorKind.NETWORK, "Error inesperado de red")
        } finally {
            conn?.disconnect()
        }
        result
    }

    private fun httpError(code: Int, body: String?): ApiResult.Err {
        var msg = ""
        var reason = ""
        if (!body.isNullOrBlank()) {
            try {
                val j = JSONObject(body)
                msg = j.optString("status_message", "")
                val err = j.optJSONObject("error")
                if (err != null) {
                    if (msg.isBlank()) msg = err.optString("message", "")
                    reason = err.optJSONArray("errors").objects().firstOrNull()?.optString("reason", "") ?: ""
                }
            } catch (e: Exception) {
                // cuerpo no JSON
            }
        }
        val quota = reason.contains("quota", ignoreCase = true) || msg.contains("quota", ignoreCase = true)
        return when {
            quota -> ApiResult.Err(ErrorKind.QUOTA, "Se agotó la cuota diaria del servicio", code)
            code == 401 -> ApiResult.Err(ErrorKind.HTTP, "Credencial rechazada (401). Revisa la clave configurada", code)
            code == 400 && msg.contains("key", ignoreCase = true) ->
                ApiResult.Err(ErrorKind.HTTP, "Clave no válida (400)", code)
            code == 403 -> ApiResult.Err(ErrorKind.HTTP, "Acceso denegado (403). Revisa la clave y sus permisos", code)
            code == 404 -> ApiResult.Err(ErrorKind.HTTP, "No encontrado (404)", code)
            code == 429 -> ApiResult.Err(ErrorKind.HTTP, "Demasiadas solicitudes (429). Inténtalo más tarde", code)
            else -> ApiResult.Err(ErrorKind.HTTP, "Error del servicio ($code)", code)
        }
    }

    private fun redact(url: String): String =
        url.replace(Regex("([?&](api_key|key)=)[^&]*"), "$1***")
}
