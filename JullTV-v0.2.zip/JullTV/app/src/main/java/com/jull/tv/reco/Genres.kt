package com.jull.tv.reco

/** Géneros elegibles. TMDB usa identificadores distintos para películas y series. */
data class GenreChoice(val id: String, val label: String, val movieId: Int?, val tvId: Int?)

object Genres {
    val all: List<GenreChoice> = listOf(
        GenreChoice("action", "Acción", 28, 10759),
        GenreChoice("adventure", "Aventura", 12, 10759),
        GenreChoice("animation", "Animación", 16, 16),
        GenreChoice("comedy", "Comedia", 35, 35),
        GenreChoice("crime", "Crimen", 80, 80),
        GenreChoice("documentary", "Documental", 99, 99),
        GenreChoice("drama", "Drama", 18, 18),
        GenreChoice("family", "Familia", 10751, 10751),
        GenreChoice("fantasy", "Fantasía", 14, 10765),
        GenreChoice("mystery", "Misterio", 9648, 9648),
        GenreChoice("scifi", "Ciencia ficción", 878, 10765),
        GenreChoice("horror", "Terror", 27, null),
        GenreChoice("romance", "Romance", 10749, null),
        GenreChoice("thriller", "Suspenso", 53, null),
        GenreChoice("war", "Bélico", 10752, 10768),
        GenreChoice("western", "Western", 37, 37),
    )

    fun movieIds(ids: Set<String>): List<Int> =
        all.filter { it.id in ids }.mapNotNull { it.movieId }.distinct()

    fun tvIds(ids: Set<String>): List<Int> =
        all.filter { it.id in ids }.mapNotNull { it.tvId }.distinct()

    /** Todos los identificadores TMDB (película y serie) de los géneros indicados. */
    fun allIds(ids: Set<String>): Set<Int> = (movieIds(ids) + tvIds(ids)).toSet()
}
