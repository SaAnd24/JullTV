package com.jull.tv.catalog

import com.jull.tv.config.AppConfig
import com.jull.tv.net.ApiResult
import com.jull.tv.net.ErrorKind
import com.jull.tv.net.Http
import com.jull.tv.net.doubleOrNull
import com.jull.tv.net.ints
import com.jull.tv.net.map
import com.jull.tv.net.objects
import com.jull.tv.net.strOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Cliente de la API oficial v3 de TMDB. Admite clave v3 (api_key) o token v4 (Bearer, empieza por "eyJ"). */
class TmdbClient {

    private val base = "https://api.themoviedb.org/3"

    private suspend fun get(path: String, params: Map<String, String>): ApiResult<JSONObject> {
        val key = AppConfig.tmdbKey
        if (key.isBlank()) {
            return ApiResult.Err(ErrorKind.NOT_CONFIGURED, "TMDB no está configurado")
        }
        val query = LinkedHashMap(params)
        val headers = HashMap<String, String>()
        if (key.startsWith("eyJ")) headers["Authorization"] = "Bearer $key" else query["api_key"] = key
        val qs = query.entries.joinToString("&") { "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}" }
        return Http.getJson("$base$path?$qs", headers)
    }

    /** media = "movie" | "tv"; list = popular | top_rated | upcoming | on_the_air */
    suspend fun list(media: String, list: String, page: Int): ApiResult<Page> {
        val params = linkedMapOf("language" to AppConfig.LANGUAGE, "page" to page.toString())
        if (media == "movie" && list == "upcoming") params["region"] = AppConfig.REGION
        return get("/$media/$list", params).map { parsePage(it, media) }
    }

    suspend fun discover(
        media: String,
        page: Int,
        sortBy: String = "popularity.desc",
        withGenres: String? = null,
        withoutGenres: String? = null,
        originalLanguage: String? = null,
        minVotes: Int? = null,
    ): ApiResult<Page> {
        val params = linkedMapOf(
            "language" to AppConfig.LANGUAGE,
            "page" to page.toString(),
            "sort_by" to sortBy,
            "include_adult" to "false",
        )
        if (!withGenres.isNullOrBlank()) params["with_genres"] = withGenres
        if (!withoutGenres.isNullOrBlank()) params["without_genres"] = withoutGenres
        if (!originalLanguage.isNullOrBlank()) params["with_original_language"] = originalLanguage
        if (minVotes != null) params["vote_count.gte"] = minVotes.toString()
        return get("/discover/$media", params).map { parsePage(it, media) }
    }

    /** Anime = animación (género 16) con idioma original japonés. */
    suspend fun anime(page: Int, topRated: Boolean): ApiResult<Page> =
        if (topRated) {
            discover("tv", page, sortBy = "vote_average.desc", withGenres = "16", originalLanguage = "ja", minVotes = 200)
        } else {
            discover("tv", page, withGenres = "16", originalLanguage = "ja")
        }

    suspend fun search(query: String): ApiResult<Page> {
        val params = linkedMapOf(
            "query" to query,
            "language" to AppConfig.LANGUAGE,
            "page" to "1",
            "include_adult" to "false",
        )
        return get("/search/multi", params).map { parsePage(it, null) }
    }

    suspend fun recommendations(item: ContentItem, page: Int): ApiResult<Page> {
        val media = item.tmdbMedia ?: return ApiResult.Err(ErrorKind.PARSE, "Elemento sin origen TMDB")
        val id = item.tmdbId ?: return ApiResult.Err(ErrorKind.PARSE, "Elemento sin identificador")
        val params = linkedMapOf("language" to AppConfig.LANGUAGE, "page" to page.toString())
        return get("/$media/$id/recommendations", params).map { parsePage(it, media) }
    }

    suspend fun details(item: ContentItem): ApiResult<Details> {
        val media = item.tmdbMedia ?: return ApiResult.Err(ErrorKind.PARSE, "Elemento sin origen TMDB")
        val id = item.tmdbId ?: return ApiResult.Err(ErrorKind.PARSE, "Elemento sin identificador")
        return when (val r = get("/$media/$id", mapOf("language" to AppConfig.LANGUAGE))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> {
                val j = r.value
                var overview = j.strOrNull("overview")
                var fallback = false
                if (overview == null) {
                    // Sin sinopsis en español: se intenta el inglés y se avisa de ello.
                    val en = get("/$media/$id", mapOf("language" to "en-US"))
                    if (en is ApiResult.Ok) {
                        overview = en.value.strOrNull("overview")
                        fallback = overview != null
                    }
                }
                val runtime = if (media == "movie") j.optInt("runtime", 0).takeIf { it > 0 } else null
                val seasons = if (media == "tv") j.optInt("number_of_seasons", 0).takeIf { it > 0 } else null
                val episodes = if (media == "tv") j.optInt("number_of_episodes", 0).takeIf { it > 0 } else null
                ApiResult.Ok(
                    Details(
                        genres = j.optJSONArray("genres").objects().mapNotNull { it.strOrNull("name") },
                        overview = overview,
                        overviewIsFallbackLanguage = fallback,
                        runtimeMinutes = runtime,
                        seasons = seasons,
                        episodes = episodes,
                        tagline = j.strOrNull("tagline"),
                        status = j.strOrNull("status"),
                    ),
                )
            }
        }
    }

    /** Proveedores de TMDB (datos de JustWatch) para Ecuador. No confirman acceso directo. */
    suspend fun providers(item: ContentItem): ApiResult<Providers> {
        val media = item.tmdbMedia ?: return ApiResult.Err(ErrorKind.PARSE, "Elemento sin origen TMDB")
        val id = item.tmdbId ?: return ApiResult.Err(ErrorKind.PARSE, "Elemento sin identificador")
        return get("/$media/$id/watch/providers", emptyMap()).map { j ->
            val region = j.optJSONObject("results")?.optJSONObject(AppConfig.REGION)
            if (region == null) {
                Providers(false, emptyList(), emptyList(), emptyList(), emptyList())
            } else {
                Providers(
                    regionFound = true,
                    flatrate = names(region.optJSONArray("flatrate")),
                    free = (names(region.optJSONArray("free")) + names(region.optJSONArray("ads"))).distinct(),
                    rent = names(region.optJSONArray("rent")),
                    buy = names(region.optJSONArray("buy")),
                )
            }
        }
    }

    private fun names(arr: JSONArray?): List<String> =
        arr.objects().mapNotNull { it.strOrNull("provider_name") }

    private fun parsePage(j: JSONObject, forcedMedia: String?): Page {
        val items = ArrayList<ContentItem>()
        for (o in j.optJSONArray("results").objects()) {
            parseItem(o, forcedMedia)?.let { items.add(it) }
        }
        return Page(items, j.optInt("total_pages", 1).coerceAtLeast(1))
    }

    private fun parseItem(o: JSONObject, forcedMedia: String?): ContentItem? {
        val media = forcedMedia ?: o.optString("media_type", "")
        if (media != "movie" && media != "tv") return null
        val id = o.optInt("id", -1)
        if (id < 0) return null
        val rawTitle: String? = if (media == "movie") {
            o.strOrNull("title") ?: o.strOrNull("original_title")
        } else {
            o.strOrNull("name") ?: o.strOrNull("original_name")
        }
        val title = rawTitle ?: return null
        val genres = o.optJSONArray("genre_ids").ints()
        val isAnime = 16 in genres && o.optString("original_language", "") == "ja"
        val kind = when {
            isAnime -> Kind.ANIME
            media == "movie" -> Kind.MOVIE
            else -> Kind.SERIES
        }
        val date = if (media == "movie") o.strOrNull("release_date") else o.strOrNull("first_air_date")
        val rating = if (o.optInt("vote_count", 0) > 0) o.doubleOrNull("vote_average") else null
        return ContentItem(
            key = "tmdb:$media:$id",
            kind = kind,
            title = title,
            overview = o.strOrNull("overview"),
            posterPath = o.strOrNull("poster_path"),
            backdropPath = o.strOrNull("backdrop_path"),
            date = date,
            rating = rating,
            genreIds = genres,
        )
    }
}
