package com.jull.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.RowStatus
import com.jull.tv.catalog.Section
import com.jull.tv.config.AppConfig
import com.jull.tv.data.InstalledApp
import com.jull.tv.integration.Integrations
import com.jull.tv.util.AppLauncher

@Composable
fun BrowseScreen(
    section: Section,
    nav: HomeViewModel,
    catalog: CatalogViewModel,
    appsState: AppsUiState,
    onOpenApp: (InstalledApp) -> Unit,
) {
    val context = LocalContext.current
    val rows by catalog.rows.collectAsStateWithLifecycle()
    val ids by produceState(initialValue = emptyList<String>(), section) {
        value = catalog.ensureBrowse(section)
    }
    val firstRow = ids.firstOrNull()?.let { rows[it] }
    val isYouTube = section == Section.YOUTUBE
    val ready = isYouTube || ids.isEmpty() || (firstRow != null && firstRow.status != RowStatus.LOADING)
    val first = rememberScreenFocus(nav.focus, ready = ready)
    val openItem: (ContentItem) -> Unit = { nav.push(Screen.Detail(it)) }

    val (title, subtitle) = when (section) {
        Section.MOVIES -> "Películas" to "Datos de TMDB"
        Section.SERIES -> "Series" to "Datos de TMDB"
        Section.ANIME -> "Anime" to "Series de animación japonesa · datos de TMDB"
        Section.YOUTUBE -> "YouTube" to "Búsqueda y vídeos públicos; JullTV no accede a tu historial de YouTube"
    }

    ScreenScaffold(title = title, subtitle = subtitle) {
        if (isYouTube) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                TvButton(
                    text = "Buscar vídeos",
                    onClick = { nav.push(Screen.Search) },
                    modifier = Modifier.focusRequester(first),
                )
                TvButton(
                    text = "Abrir YouTube",
                    onClick = {
                        val app = appsState.apps.firstOrNull { Integrations.isYouTube(it) }
                        if (app != null) onOpenApp(app) else AppLauncher.openUrl(context, "https://www.youtube.com")
                    },
                )
            }
        }
        if (ids.isEmpty()) {
            if (isYouTube) {
                InfoText(
                    "La API de YouTube no está configurada (es opcional). Puedes buscar con el buscador oficial " +
                        "de YouTube o abrir la aplicación. Instrucciones en Ajustes.",
                    Modifier.padding(top = 8.dp),
                )
            } else {
                InfoText(
                    "El catálogo de TMDB no está configurado. Instrucciones en Ajustes.",
                    Modifier.padding(top = 8.dp),
                )
                TvButton(
                    text = "Abrir ajustes",
                    onClick = { nav.push(Screen.Settings) },
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .focusRequester(first),
                )
            }
        } else {
            LazyColumn(
                state = nav.listState("browse:${section.name}"),
                modifier = Modifier
                    .fillMaxSize()
                    .fillMaxWidth(),
                contentPadding = PaddingValues(bottom = 40.dp),
            ) {
                items(ids, key = { it }) { id ->
                    ContentRow(
                        rowId = id,
                        state = rows[id],
                        nav = nav,
                        catalog = catalog,
                        onOpen = openItem,
                        updateHero = false,
                        firstFocus = if (!isYouTube && id == ids.first()) first else null,
                    )
                }
            }
        }
        if (AppConfig.tmdbConfigured && ids.isEmpty() && !isYouTube) {
            // Sin filas aunque haya clave: no debería ocurrir; se deja el mensaje de ajustes.
        }
    }
}
