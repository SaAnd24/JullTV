package com.jull.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.catalog.Section
import com.jull.tv.local.TrackedItem
import com.jull.tv.local.WatchStatus

@Composable
fun TrackingScreen(nav: HomeViewModel, catalog: CatalogViewModel) {
    val store by catalog.storeState.collectAsStateWithLifecycle()
    val first = rememberScreenFocus(nav.focus)
    val sorted = remember(store.tracked) {
        store.tracked.sortedWith(
            compareBy<TrackedItem> {
                when (it.status) {
                    WatchStatus.IN_PROGRESS -> 0
                    WatchStatus.PENDING -> 1
                    WatchStatus.FINISHED -> 2
                }
            }.thenByDescending { it.updatedAt },
        )
    }

    ScreenScaffold(
        title = "Continuar viendo",
        subtitle = "Seguimiento local de JullTV · el progreso lo anotas tú",
    ) {
        if (sorted.isEmpty()) {
            InfoText("Aún no hay títulos. Abre la ficha de una película, serie, anime o vídeo y añádelo.")
            TvButton(
                text = "Explorar películas",
                onClick = { nav.push(Screen.Browse(Section.MOVIES)) },
                modifier = Modifier
                    .padding(top = 12.dp)
                    .focusRequester(first),
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 200.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(sorted, key = { _, t -> t.item.key }) { index, t ->
                    ContentCard(
                        item = t.item,
                        onClick = { nav.push(Screen.Detail(t.item)) },
                        modifier = Modifier.trackFocus(
                            key = "trk:${t.item.key}",
                            memory = nav.focus,
                            first = if (index == 0) first else null,
                        ),
                        progress = t.progressPercent?.let { it / 100f },
                        caption = t.caption(),
                    )
                }
            }
        }
    }
}
