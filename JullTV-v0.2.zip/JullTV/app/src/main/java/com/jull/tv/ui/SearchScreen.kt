package com.jull.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Kind
import com.jull.tv.catalog.RowState
import com.jull.tv.catalog.RowStatus
import com.jull.tv.data.InstalledApp
import com.jull.tv.integration.Integrations
import com.jull.tv.ui.theme.JullColors
import com.jull.tv.util.AppLauncher
import com.jull.tv.youtube.YouTubeClient

@Composable
fun SearchScreen(
    nav: HomeViewModel,
    catalog: CatalogViewModel,
    appsState: AppsUiState,
) {
    val context = LocalContext.current
    val ui by catalog.search.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf(ui.query) }
    var fieldFocused by remember { mutableStateOf(false) }
    val fieldFocus = rememberScreenFocus(nav.focus)
    val keyboard = LocalSoftwareKeyboardController.current
    val openItem: (ContentItem) -> Unit = { nav.push(Screen.Detail(it)) }
    val shape = RoundedCornerShape(14.dp)

    LaunchedEffect(fieldFocused) {
        if (fieldFocused) keyboard?.show()
    }

    fun submit() {
        keyboard?.hide()
        catalog.search(text)
    }

    ScreenScaffold(
        title = "Buscar",
        subtitle = "Películas, series, anime y vídeos de YouTube. Pulsa Enter en el teclado para buscar",
    ) {
        BasicTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            textStyle = TextStyle(color = JullColors.TextPrimary, fontSize = 24.sp),
            cursorBrush = SolidColor(JullColors.Turquoise),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }),
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(fieldFocus)
                .onFocusChanged { fieldFocused = it.isFocused },
            decorationBox = { inner ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .focusGlow(fieldFocused, shape)
                        .clip(shape)
                        .background(JullColors.Surface)
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                ) {
                    if (text.isEmpty()) {
                        Text(
                            text = "Escribe un título, serie, anime o vídeo…",
                            color = JullColors.TextSecondary,
                            fontSize = 22.sp,
                        )
                    }
                    inner()
                }
            },
        )

        LazyColumn(
            state = nav.listState("search_list"),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
        ) {
            item(key = "go") {
                TvButton(text = "Buscar", onClick = { submit() })
            }

            // ----- Películas, series y anime (TMDB) -----
            when (ui.tmdbStatus) {
                LoadStatus.IDLE -> {}
                LoadStatus.NOT_CONFIGURED -> item(key = "tmdb_nc") {
                    InfoText(
                        "El catálogo de TMDB no está configurado: no hay búsqueda de películas, series ni anime. " +
                            "Instrucciones en Ajustes.",
                        Modifier.padding(top = 14.dp),
                    )
                }
                LoadStatus.LOADING -> item(key = "tmdb_load") {
                    InfoText("Buscando películas, series y anime…", Modifier.padding(top = 14.dp))
                }
                LoadStatus.ERROR -> item(key = "tmdb_err") {
                    InfoText(ui.tmdbError ?: "No se pudo buscar", Modifier.padding(top = 14.dp))
                    TvButton(
                        text = "Reintentar",
                        onClick = { catalog.search(ui.query) },
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                LoadStatus.READY -> {
                    val groups = listOf(
                        Triple("s_movies", "Películas", ui.tmdbItems.filter { it.kind == Kind.MOVIE }),
                        Triple("s_series", "Series", ui.tmdbItems.filter { it.kind == Kind.SERIES }),
                        Triple("s_anime", "Anime", ui.tmdbItems.filter { it.kind == Kind.ANIME }),
                    )
                    if (groups.all { it.third.isEmpty() }) {
                        item(key = "tmdb_none") {
                            InfoText("Sin resultados en TMDB para «${ui.query}».", Modifier.padding(top = 14.dp))
                        }
                    }
                    for ((id, title, list) in groups) {
                        if (list.isNotEmpty()) {
                            item(key = id) {
                                ContentRow(
                                    rowId = id,
                                    state = RowState(id, title, list, RowStatus.READY, page = 1, totalPages = 1),
                                    nav = nav,
                                    catalog = catalog,
                                    onOpen = openItem,
                                    updateHero = false,
                                )
                            }
                        }
                    }
                }
            }

            // ----- YouTube -----
            when (ui.ytStatus) {
                LoadStatus.IDLE -> {}
                LoadStatus.NOT_CONFIGURED -> item(key = "yt_nc") {
                    InfoText(
                        "La API de YouTube no está configurada (opcional). Usa la búsqueda oficial de YouTube:",
                        Modifier.padding(top = 14.dp),
                    )
                }
                LoadStatus.LOADING -> item(key = "yt_load") {
                    InfoText("Buscando en YouTube…", Modifier.padding(top = 14.dp))
                }
                LoadStatus.ERROR -> item(key = "yt_err") {
                    InfoText(ui.ytError ?: "No se pudo buscar en YouTube", Modifier.padding(top = 14.dp))
                }
                LoadStatus.READY -> {
                    if (ui.ytVideos.isNotEmpty()) {
                        item(key = "s_ytv") {
                            ContentRow(
                                rowId = "s_ytv",
                                state = RowState("s_ytv", "Vídeos de YouTube", ui.ytVideos, RowStatus.READY, page = 1, totalPages = 1),
                                nav = nav,
                                catalog = catalog,
                                onOpen = openItem,
                                updateHero = false,
                            )
                        }
                    }
                    if (ui.ytChannels.isNotEmpty()) {
                        item(key = "s_ytc") {
                            ContentRow(
                                rowId = "s_ytc",
                                state = RowState("s_ytc", "Canales de YouTube", ui.ytChannels, RowStatus.READY, page = 1, totalPages = 1),
                                nav = nav,
                                catalog = catalog,
                                onOpen = openItem,
                                updateHero = false,
                            )
                        }
                    }
                    if (ui.ytVideos.isEmpty() && ui.ytChannels.isEmpty()) {
                        item(key = "yt_none") {
                            InfoText("Sin resultados en YouTube para «${ui.query}».", Modifier.padding(top = 14.dp))
                        }
                    }
                }
            }
            if (ui.query.isNotBlank()) {
                item(key = "yt_official") {
                    TvButton(
                        text = "Abrir búsqueda «${ui.query}» en YouTube",
                        onClick = {
                            val pkg = appsState.apps.firstOrNull { Integrations.isYouTube(it) }?.packageName
                            AppLauncher.openUrl(context, YouTubeClient.searchUrl(ui.query), pkg)
                        },
                        modifier = Modifier.padding(top = 14.dp),
                    )
                }
            }
        }
    }
}
