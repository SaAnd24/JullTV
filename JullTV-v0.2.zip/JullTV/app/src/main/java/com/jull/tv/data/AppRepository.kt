package com.jull.tv.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.jull.tv.util.AppLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Descubre las aplicaciones instaladas que se pueden abrir desde el launcher. */
class AppRepository(private val context: Context) {

    private class CachedImage(val bitmap: ImageBitmap, val isBanner: Boolean)

    private val imageCache = HashMap<String, CachedImage>()

    suspend fun loadApps(): List<InstalledApp> = withContext(Dispatchers.Default) {
        val pm = context.packageManager
        val own = context.packageName

        val tvEntries = query(pm, Intent.CATEGORY_LEANBACK_LAUNCHER)
        val launcherEntries = query(pm, Intent.CATEGORY_LAUNCHER)
        AppLog.d("Actividades leanback=${tvEntries.size}, launcher=${launcherEntries.size}")

        val byPackage = LinkedHashMap<String, InstalledApp>()
        for (info in tvEntries) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == own || byPackage.containsKey(pkg)) continue
            toApp(pm, info, isTv = true)?.let { byPackage[pkg] = it }
        }
        for (info in launcherEntries) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == own || byPackage.containsKey(pkg)) continue
            toApp(pm, info, isTv = false)?.let { byPackage[pkg] = it }
        }

        val apps = byPackage.values.sortedWith(
            compareBy<InstalledApp> { if (isPinned(it)) 0 else 1 }
                .thenBy { it.label.lowercase() }
        )
        val validKeys = apps.map { it.key }.toSet()
        imageCache.keys.retainAll(validKeys)
        AppLog.d("Aplicaciones detectadas: ${apps.size}")
        apps
    }

    @Suppress("DEPRECATION")
    private fun query(pm: PackageManager, category: String): List<ResolveInfo> {
        return try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            pm.queryIntentActivities(intent, 0)
        } catch (e: Exception) {
            AppLog.e("Error consultando $category", e)
            emptyList()
        }
    }

    private fun toApp(pm: PackageManager, info: ResolveInfo, isTv: Boolean): InstalledApp? {
        try {
            val ai = info.activityInfo ?: return null
            val key = "${ai.packageName}/${ai.name}"
            val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: ai.packageName

            val cached = imageCache[key]
            val image = cached ?: run {
                val banner = if (isTv) ai.loadBanner(pm) else null
                val created = if (banner != null) {
                    CachedImage(banner.toBitmap(320, 180).asImageBitmap(), true)
                } else {
                    CachedImage(info.loadIcon(pm).toBitmap(128, 128).asImageBitmap(), false)
                }
                imageCache[key] = created
                created
            }
            return InstalledApp(label, ai.packageName, ai.name, image.bitmap, image.isBanner, isTv)
        } catch (e: Exception) {
            AppLog.e("No se pudo leer ${info.activityInfo?.packageName}", e)
            return null
        }
    }

    /** YouTube y Xuper TV aparecen primero si están instaladas; el resto se ordena por nombre. */
    private fun isPinned(app: InstalledApp): Boolean {
        val text = (app.label + " " + app.packageName).lowercase()
        return text.contains("youtube") || text.contains("xuper")
    }
}
