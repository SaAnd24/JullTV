package com.jull.tv.ui

import android.content.Context
import android.text.format.DateFormat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import com.jull.tv.R
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Images
import com.jull.tv.data.InstalledApp
import com.jull.tv.ui.theme.JullColors
import kotlinx.coroutines.delay
import java.util.Date

private val CardWidth = 200.dp

/** Contorno turquesa discreto con brillo suave cuando el elemento tiene el foco. */
@Composable
fun Modifier.focusGlow(focused: Boolean, shape: Shape): Modifier {
    val elevation by animateDpAsState(if (focused) 18.dp else 0.dp, tween(140), label = "glowElevation")
    val borderColor by animateColorAsState(
        if (focused) JullColors.Turquoise else Color.White.copy(alpha = 0.08f),
        tween(140),
        label = "glowBorder",
    )
    val borderWidth = if (focused) 3.dp else 1.dp
    return this
        .shadow(
            elevation = elevation,
            shape = shape,
            clip = false,
            ambientColor = JullColors.Turquoise,
            spotColor = JullColors.Turquoise,
        )
        .border(borderWidth, borderColor, shape)
}

/** Tarjeta base 16:9 con texto debajo. Se activa con OK/Enter. */
@Composable
fun TvCard(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    caption: String? = null,
    onFocus: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(if (focused) 1.08f else 1f, tween(140), label = "cardScale")
    val shape = RoundedCornerShape(16.dp)

    if (onFocus != null) {
        LaunchedEffect(focused) { if (focused) onFocus() }
    }

    Column(
        modifier = modifier
            .width(CardWidth)
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .focusGlow(focused, shape)
                .clip(shape)
                .background(JullColors.Surface),
            content = content,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = label,
            color = if (focused) JullColors.TextPrimary else JullColors.TextSecondary,
            fontSize = 18.sp,
            fontWeight = if (focused) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        if (caption != null) {
            Text(
                text = caption,
                color = JullColors.TextSecondary,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
fun AppCard(app: InstalledApp, onClick: () -> Unit, modifier: Modifier = Modifier) {
    TvCard(label = app.label, onClick = onClick, modifier = modifier) {
        if (app.isBanner) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(64.dp),
            )
        }
    }
}

@Composable
fun ActionCard(label: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    TvCard(label = label, onClick = onClick, modifier = modifier) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = JullColors.Turquoise,
            modifier = Modifier
                .align(Alignment.Center)
                .size(44.dp),
        )
    }
}

/** Imagen remota con caché (Coil). Si no hay URL o falla la carga, no dibuja nada y se ve el fondo. */
@Composable
fun RemoteImage(url: String?, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Crop) {
    if (url == null) return
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = contentScale,
        modifier = modifier,
    )
}

/** Tarjeta de contenido (película, serie, anime, vídeo o canal). Tolera la ausencia de imágenes. */
@Composable
fun ContentCard(
    item: ContentItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onFocus: (() -> Unit)? = null,
    progress: Float? = null,
    caption: String? = null,
) {
    val backdrop = Images.backdrop(item.backdropPath, "w300")
    val poster = if (backdrop == null) Images.poster(item.posterPath, "w185") else null
    val defaultCaption = listOfNotNull(item.kind.label, item.year).joinToString(" · ")
    TvCard(
        label = item.title,
        onClick = onClick,
        modifier = modifier,
        caption = caption ?: defaultCaption,
        onFocus = onFocus,
    ) {
        // Texto de respaldo: visible mientras carga o si la imagen no existe
        Text(
            text = item.title,
            color = JullColors.TextSecondary,
            fontSize = 14.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(10.dp),
        )
        if (backdrop != null) {
            RemoteImage(backdrop, Modifier.fillMaxSize(), ContentScale.Crop)
        } else if (poster != null) {
            RemoteImage(poster, Modifier.fillMaxSize(), ContentScale.Fit)
        }
        if (progress != null) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(5.dp)
                    .background(Color.Black.copy(alpha = 0.55f)),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .background(JullColors.Turquoise),
                )
            }
        }
    }
}

@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    selectedColor: Color = JullColors.TurquoiseDeep,
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(14.dp)
    val bg = when {
        focused -> JullColors.TurquoiseDeep
        selected -> selectedColor
        else -> JullColors.SurfaceHigh
    }
    Box(
        modifier = modifier
            .focusGlow(focused, shape)
            .clip(shape)
            .background(bg)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = JullColors.TextPrimary,
            fontSize = 19.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
        )
    }
}

@Composable
fun SettingsButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .size(44.dp)
            .focusGlow(focused, CircleShape)
            .clip(CircleShape)
            .background(if (focused) JullColors.TurquoiseDeep else JullColors.SurfaceHigh)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.Settings,
            contentDescription = stringResource(R.string.settings),
            tint = JullColors.TextPrimary,
            modifier = Modifier.size(26.dp),
        )
    }
}

@Composable
fun ClockText(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val time by produceState(initialValue = formatTime(context)) {
        while (true) {
            value = formatTime(context)
            delay(15_000)
        }
    }
    Text(
        text = time,
        color = JullColors.TextPrimary,
        fontSize = 24.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier,
    )
}

private fun formatTime(context: Context): String =
    DateFormat.getTimeFormat(context).format(Date())

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = JullColors.TextPrimary,
        fontSize = 22.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier.padding(top = 6.dp),
    )
}

@Composable
fun InfoText(text: String, modifier: Modifier = Modifier, color: Color = JullColors.TextSecondary) {
    Text(text = text, color = color, fontSize = 18.sp, modifier = modifier)
}

@Composable
fun Stepper(label: String, valueText: String, onMinus: () -> Unit, onPlus: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(text = "$label: $valueText", color = JullColors.TextPrimary, fontSize = 18.sp)
        TvButton(text = "−", onClick = onMinus)
        TvButton(text = "+", onClick = onPlus)
    }
}

/** Marco común de pantallas secundarias: título, subtítulo y hora. */
@Composable
fun ScreenScaffold(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 48.dp, vertical = 27.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text(text = title, color = JullColors.TextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                if (subtitle != null) {
                    Text(text = subtitle, color = JullColors.TextSecondary, fontSize = 18.sp)
                }
            }
            ClockText()
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}
