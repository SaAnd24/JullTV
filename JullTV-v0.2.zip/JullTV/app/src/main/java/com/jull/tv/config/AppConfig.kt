package com.jull.tv.config

import com.jull.tv.BuildConfig

/**
 * Configuración de servicios externos. Las claves se inyectan al compilar (secretos de GitHub);
 * no existen en el código fuente. Importante: una clave dentro de un APK puede inspeccionarse.
 */
object AppConfig {
    val tmdbKey: String get() = BuildConfig.TMDB_API_KEY
    val youtubeKey: String get() = BuildConfig.YOUTUBE_API_KEY

    val tmdbConfigured: Boolean get() = tmdbKey.isNotBlank()
    val youtubeConfigured: Boolean get() = youtubeKey.isNotBlank()

    /** Español neutro de Latinoamérica; Ecuador como región para estrenos y proveedores. */
    const val LANGUAGE = "es-MX"
    const val REGION = "EC"

    val version: String get() = BuildConfig.VERSION_NAME
}
