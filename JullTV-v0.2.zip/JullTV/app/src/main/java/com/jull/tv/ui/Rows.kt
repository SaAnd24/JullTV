package com.jull.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.RowState
import com.jull.tv.catalog.RowStatus

/**
 * Fila horizontal de contenido con estados de carga, error, vacío y paginación («Ver más»).
 * El desplazamiento y el foco se conservan al abrir una ficha y volver.
 */
@Composable
fun ContentRow(
    rowId: String,
    state: RowState?,
    nav: HomeViewModel,
    catalog: CatalogViewModel,
    onOpen: (ContentItem) -> Unit,
    modifier: Modifier = Modifier,
    updateHero: Boolean = true,
    firstFocus: FocusRequester? = null,
    onLoadMore: () -> Unit = { catalog.loadNext(rowId) },
    onRetry: () -> Unit = { catalog.loadNext(rowId) },
) {
    if (state == null) return
    val listState = nav.listState("row:$rowId")

    Column(modifier) {
        SectionTitle(state.title)
        when {
            state.items.isEmpty() && state.status == RowStatus.LOADING -> {
                InfoText("Cargando…", Modifier.padding(vertical = 14.dp))
            }
            state.items.isEmpty() && state.status == RowStatus.ERROR -> {
                InfoText(state.error ?: "No se pudo cargar", Modifier.padding(top = 6.dp))
                val base = Modifier.padding(top = 8.dp, bottom = 8.dp)
                TvButton(
                    text = "Reintentar",
                    onClick = onRetry,
                    modifier = if (firstFocus != null) base.focusRequester(firstFocus) else base,
                )
            }
            state.items.isEmpty() -> {
                InfoText("Sin resultados", Modifier.padding(vertical = 14.dp))
            }
            else -> {
                LazyRow(
                    state = listState,
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    itemsIndexed(state.items, key = { _, c -> c.key }) { index, item ->
                        ContentCard(
                            item = item,
                            onClick = { onOpen(item) },
                            modifier = Modifier.trackFocus(
                                key = "$rowId:${item.key}",
                                memory = nav.focus,
                                first = if (index == 0) firstFocus else null,
                            ),
                            onFocus = if (updateHero) ({ catalog.onItemFocused(item) }) else null,
                        )
                    }
                    if (state.error != null) {
                        item(key = "retry") {
                            ActionCard("Reintentar", Icons.Filled.Refresh, onRetry)
                        }
                    } else if (state.hasMore) {
                        item(key = "more") {
                            ActionCard("Ver más", Icons.Filled.Add, onLoadMore)
                        }
                    }
                }
            }
        }
    }
}
