package com.jull.tv.integration

import com.jull.tv.data.InstalledApp

/** Estados posibles de la integración con una aplicación. Solo se marca lo realmente cierto. */
enum class IntegrationState(val label: String) {
    OPENABLE("Detectada y abrible"),
    LINK_ACTION("Acepta enlaces oficiales de YouTube (sin verificar en este televisor)"),
    PROGRESS_VERIFIED("Integración de progreso real verificada"),
    MANUAL("Seguimiento manual disponible"),
    NO_PROGRESS("Lectura automática de progreso: no disponible"),
}

object Integrations {
    fun isYouTube(app: InstalledApp): Boolean = app.packageName.startsWith("com.google.android.youtube")

    fun isXuper(app: InstalledApp): Boolean =
        (app.label + " " + app.packageName).lowercase().contains("xuper")

    fun isPinned(app: InstalledApp): Boolean = isYouTube(app) || isXuper(app)

    /**
     * Ninguna aplicación tiene hoy una integración de progreso verificada, por lo que
     * PROGRESS_VERIFIED no se devuelve nunca. Se añadirá solo cuando exista una API autorizada y probada.
     */
    fun statesFor(app: InstalledApp): List<IntegrationState> {
        val list = ArrayList<IntegrationState>()
        list.add(IntegrationState.OPENABLE)
        if (isYouTube(app)) list.add(IntegrationState.LINK_ACTION)
        list.add(IntegrationState.MANUAL)
        list.add(IntegrationState.NO_PROGRESS)
        return list
    }

    /** Coincidencia aproximada entre el nombre de un proveedor de TMDB y el nombre de una app instalada. */
    fun matchesProvider(app: InstalledApp, providerName: String): Boolean {
        val a = norm(app.label)
        val p = norm(providerName)
        if (a.length < 3 || p.length < 3) return false
        return a.contains(p) || p.contains(a)
    }

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }
}
