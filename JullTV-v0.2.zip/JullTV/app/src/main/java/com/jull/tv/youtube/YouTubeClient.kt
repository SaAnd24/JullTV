package com.jull.tv.youtube

import android.text.Html
import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Kind
import com.jull.tv.catalog.Page
import com.jull.tv.config.AppConfig
import com.jull.tv.net.ApiResult
import com.jull.tv.net.ErrorKind
import com.jull.tv.net.Http
import com.jull.tv.net.map
import com.jull.tv.net.objects
import com.jull.tv.net.strOrNull
import org.json.JSONObject
import java.net.URLEncoder

/**
 * YouTube Data API v3 (opcional). Solo datos públicos: no accede al historial de ninguna cuenta.
 * Cuota: search.list cuesta 100 unidades por llamada; videos.list (populares) cuesta 1.
 */
class YouTubeClient {

    private val base = "https://www.googleapis.com/youtube/v3"

    private suspend fun get(path: String, params: Map<String, String>): ApiResult<JSONObject> {
        val key = AppConfig.youtubeKey
        if (key.isBlank()) return ApiResult.Err(ErrorKind.NOT_CONFIGURED, "YouTube Data API no está configurada")
        val query = LinkedHashMap(params)
        query["key"] = key
        val qs = query.entries.joinToString("&") { "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}" }
        return Http.getJson("$base$path?$qs", ttlMs = 30 * 60_000L)
    }

    suspend fun popular(): ApiResult<Page> {
        val params = linkedMapOf(
            "part" to "snippet",
            "chart" to "mostPopular",
            "regionCode" to AppConfig.REGION,
            "maxResults" to "20",
        )
        return get("/videos", params).map { j ->
            val items = ArrayList<ContentItem>()
            for (o in j.optJSONArray("items").objects()) {
                val id = o.strOrNull("id") ?: continue
                parseVideo(id, o.optJSONObject("snippet"))?.let { items.add(it) }
            }
            Page(items, 1)
        }
    }

    suspend fun searchVideos(query: String): ApiResult<List<ContentItem>> {
        val params = linkedMapOf(
            "part" to "snippet",
            "type" to "video",
            "q" to query,
            "maxResults" to "15",
            "regionCode" to AppConfig.REGION,
            "relevanceLanguage" to "es",
            "safeSearch" to "moderate",
        )
        return get("/search", params).map { j ->
            j.optJSONArray("items").objects().mapNotNull { o ->
                val id = o.optJSONObject("id")?.strOrNull("videoId") ?: return@mapNotNull null
                parseVideo(id, o.optJSONObject("snippet"))
            }
        }
    }

    suspend fun searchChannels(query: String): ApiResult<List<ContentItem>> {
        val params = linkedMapOf(
            "part" to "snippet",
            "type" to "channel",
            "q" to query,
            "maxResults" to "10",
            "regionCode" to AppConfig.REGION,
            "relevanceLanguage" to "es",
        )
        return get("/search", params).map { j ->
            j.optJSONArray("items").objects().mapNotNull { o ->
                val id = o.optJSONObject("id")?.strOrNull("channelId") ?: return@mapNotNull null
                val sn = o.optJSONObject("snippet") ?: return@mapNotNull null
                val title = sn.strOrNull("title") ?: return@mapNotNull null
                ContentItem(
                    key = "yt:channel:$id",
                    kind = Kind.YOUTUBE_CHANNEL,
                    title = decode(title),
                    overview = sn.strOrNull("description")?.let { decode(it) },
                    posterPath = thumbnail(sn),
                    backdropPath = null,
                    date = sn.strOrNull("publishedAt")?.take(10),
                    rating = null,
                )
            }
        }
    }

    private fun parseVideo(id: String, sn: JSONObject?): ContentItem? {
        if (sn == null) return null
        val title = sn.strOrNull("title") ?: return null
        val thumb = thumbnail(sn)
        return ContentItem(
            key = "yt:video:$id",
            kind = Kind.YOUTUBE_VIDEO,
            title = decode(title),
            overview = sn.strOrNull("description")?.let { decode(it) },
            posterPath = thumb,
            backdropPath = thumb,
            date = sn.strOrNull("publishedAt")?.take(10),
            rating = null,
            channelTitle = sn.strOrNull("channelTitle")?.let { decode(it) },
        )
    }

    /** "medium" (320x180) es 16:9 real; "high" incluye franjas negras. */
    private fun thumbnail(sn: JSONObject): String? {
        val t = sn.optJSONObject("thumbnails") ?: return null
        return t.optJSONObject("medium")?.strOrNull("url")
            ?: t.optJSONObject("high")?.strOrNull("url")
            ?: t.optJSONObject("default")?.strOrNull("url")
    }

    @Suppress("DEPRECATION")
    private fun decode(s: String): String = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()

    companion object {
        fun videoUrl(id: String) = "https://www.youtube.com/watch?v=$id"
        fun channelUrl(id: String) = "https://www.youtube.com/channel/$id"
        fun searchUrl(query: String) =
            "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
    }
}
