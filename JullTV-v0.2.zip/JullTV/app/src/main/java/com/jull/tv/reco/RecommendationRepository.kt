package com.jull.tv.reco

import com.jull.tv.catalog.ContentItem
import com.jull.tv.catalog.Page
import com.jull.tv.catalog.Section
import com.jull.tv.catalog.TmdbClient
import com.jull.tv.config.AppConfig
import com.jull.tv.local.Interest
import com.jull.tv.local.TrackedItem
import com.jull.tv.local.UserPrefs
import com.jull.tv.local.WatchStatus
import com.jull.tv.net.ApiResult
import com.jull.tv.net.map
import com.jull.tv.youtube.YouTubeClient

data class RowSpec(
    val id: String,
    val title: String,
    val fetch: suspend (Int) -> ApiResult<Page>,
)

fun ApiResult<Page>.filtered(excluded: Set<Int>): ApiResult<Page> =
    if (excluded.isEmpty()) this
    else map { p -> p.copy(items = p.items.filter { it.genreIds.none { g -> g in excluded } }) }

/**
 * Reglas transparentes (sin IA): popularidad, géneros elegidos, favoritos y actividad propia de JullTV.
 * Solo usa los datos que JullTV realmente tiene.
 */
class RecommendationRepository(
    private val tmdb: TmdbClient,
    private val youtube: YouTubeClient,
) {

    /** «Para descubrir»: popularidad. Los intereses elegidos van primero. */
    fun discoverRows(prefs: UserPrefs): List<RowSpec> {
        val excluded = Genres.allIds(prefs.excludedGenres)
        val rows = ArrayList<Pair<Interest, RowSpec>>()
        if (AppConfig.tmdbConfigured) {
            rows.add(Interest.MOVIES to RowSpec("d_movies", "Películas populares") { p ->
                tmdb.list("movie", "popular", p).filtered(excluded)
            })
            rows.add(Interest.SERIES to RowSpec("d_series", "Series populares") { p ->
                tmdb.list("tv", "popular", p).filtered(excluded)
            })
            rows.add(Interest.ANIME to RowSpec("d_anime", "Anime destacado") { p ->
                tmdb.anime(p, topRated = false).filtered(excluded)
            })
        }
        if (AppConfig.youtubeConfigured) {
            rows.add(Interest.YOUTUBE to RowSpec("d_youtube", "Vídeos populares de YouTube (Ecuador)") { _ ->
                youtube.popular()
            })
        }
        return rows.sortedBy { if (it.first in prefs.interests) 0 else 1 }.map { it.second }
    }

    /** «Según tus intereses»: géneros, favoritos y títulos en curso. */
    fun interestRows(
        prefs: UserPrefs,
        favorites: List<ContentItem>,
        tracked: List<TrackedItem>,
    ): List<RowSpec> {
        val rows = ArrayList<RowSpec>()
        if (!AppConfig.tmdbConfigured) return rows
        val excluded = Genres.allIds(prefs.excludedGenres)

        if (prefs.favoriteGenres.isNotEmpty()) {
            val movieIds = Genres.movieIds(prefs.favoriteGenres)
            val tvIds = Genres.tvIds(prefs.favoriteGenres)
            val noMovie = Genres.movieIds(prefs.excludedGenres).joinToString(",")
            val noTv = Genres.tvIds(prefs.excludedGenres).joinToString(",")
            if (Interest.MOVIES in prefs.interests && movieIds.isNotEmpty()) {
                rows.add(RowSpec("interest_movies", "Películas de tus géneros") { p ->
                    tmdb.discover("movie", p, withGenres = movieIds.joinToString("|"), withoutGenres = noMovie)
                })
            }
            if (Interest.SERIES in prefs.interests && tvIds.isNotEmpty()) {
                rows.add(RowSpec("interest_series", "Series de tus géneros") { p ->
                    tmdb.discover("tv", p, withGenres = tvIds.joinToString("|"), withoutGenres = noTv)
                })
            }
        }

        val favTmdb = favorites.filter { it.isTmdb }.take(2)
        for (fav in favTmdb) {
            rows.add(RowSpec("fav_${fav.key}", "Porque marcaste «${fav.title}» como favorito") { p ->
                tmdb.recommendations(fav, p).filtered(excluded)
            })
        }

        val favKeys = favTmdb.map { it.key }.toSet()
        val active = tracked
            .filter { it.status == WatchStatus.IN_PROGRESS && it.item.isTmdb && it.item.key !in favKeys }
            .maxByOrNull { it.updatedAt }
        if (active != null) {
            rows.add(RowSpec("act_${active.item.key}", "Porque sigues «${active.item.title}»") { p ->
                tmdb.recommendations(active.item, p).filtered(excluded)
            })
        }
        return rows
    }

    /** Filas de las pantallas de exploración. */
    fun browseRows(section: Section): List<RowSpec> {
        val rows = ArrayList<RowSpec>()
        when (section) {
            Section.MOVIES -> if (AppConfig.tmdbConfigured) {
                rows.add(RowSpec("b_movie_popular", "Películas populares") { p -> tmdb.list("movie", "popular", p) })
                rows.add(RowSpec("b_movie_top", "Películas mejor valoradas") { p -> tmdb.list("movie", "top_rated", p) })
                rows.add(RowSpec("b_movie_up", "Próximos estrenos") { p -> tmdb.list("movie", "upcoming", p) })
            }
            Section.SERIES -> if (AppConfig.tmdbConfigured) {
                rows.add(RowSpec("b_tv_popular", "Series populares") { p -> tmdb.list("tv", "popular", p) })
                rows.add(RowSpec("b_tv_top", "Series mejor valoradas") { p -> tmdb.list("tv", "top_rated", p) })
                rows.add(RowSpec("b_tv_air", "Series en emisión") { p -> tmdb.list("tv", "on_the_air", p) })
            }
            Section.ANIME -> if (AppConfig.tmdbConfigured) {
                rows.add(RowSpec("b_anime_pop", "Anime popular") { p -> tmdb.anime(p, topRated = false) })
                rows.add(RowSpec("b_anime_top", "Anime mejor valorado") { p -> tmdb.anime(p, topRated = true) })
            }
            Section.YOUTUBE -> if (AppConfig.youtubeConfigured) {
                rows.add(RowSpec("b_yt_pop", "Populares en YouTube (Ecuador)") { _ -> youtube.popular() })
            }
        }
        return rows
    }
}
