package com.jull.tv.catalog

import androidx.compose.runtime.Immutable

enum class Kind(val label: String) {
    MOVIE("Película"),
    SERIES("Serie"),
    ANIME("Anime"),
    YOUTUBE_VIDEO("Vídeo de YouTube"),
    YOUTUBE_CHANNEL("Canal de YouTube"),
}

enum class Section { MOVIES, SERIES, ANIME, YOUTUBE }

/**
 * Elemento mostrable. `key` identifica el origen: "tmdb:movie:123", "tmdb:tv:456",
 * "yt:video:ID", "yt:channel:ID". Las rutas de imagen de TMDB son relativas;
 * las de YouTube son URLs completas.
 */
@Immutable
data class ContentItem(
    val key: String,
    val kind: Kind,
    val title: String,
    val overview: String?,
    val posterPath: String?,
    val backdropPath: String?,
    val date: String?,
    val rating: Double?,
    val genreIds: List<Int> = emptyList(),
    val channelTitle: String? = null,
) {
    val isTmdb: Boolean get() = key.startsWith("tmdb:")
    val isYoutube: Boolean get() = key.startsWith("yt:")
    val tmdbMedia: String? get() = if (isTmdb) key.split(":").getOrNull(1) else null
    val tmdbId: Int? get() = if (isTmdb) key.split(":").getOrNull(2)?.toIntOrNull() else null
    val youtubeId: String? get() = if (isYoutube) key.substringAfterLast(":") else null
    val year: String? get() = date?.takeIf { it.length >= 4 }?.substring(0, 4)
}

@Immutable
data class Page(val items: List<ContentItem>, val totalPages: Int)

@Immutable
data class Details(
    val genres: List<String>,
    val overview: String?,
    val overviewIsFallbackLanguage: Boolean,
    val runtimeMinutes: Int?,
    val seasons: Int?,
    val episodes: Int?,
    val tagline: String?,
    val status: String?,
)

@Immutable
data class Providers(
    val regionFound: Boolean,
    val flatrate: List<String>,
    val free: List<String>,
    val rent: List<String>,
    val buy: List<String>,
)

/** URLs de imagen de TMDB (https://developer.themoviedb.org/docs/image-basics). */
object Images {
    private const val BASE = "https://image.tmdb.org/t/p/"

    fun backdrop(path: String?, size: String = "w780"): String? = build(path, size)
    fun poster(path: String?, size: String = "w342"): String? = build(path, size)

    private fun build(path: String?, size: String): String? = when {
        path.isNullOrBlank() -> null
        path.startsWith("http") -> path
        else -> BASE + size + path
    }
}

enum class RowStatus { LOADING, READY, EMPTY, ERROR }

const val MAX_ROW_ITEMS = 60

@Immutable
data class RowState(
    val id: String,
    val title: String,
    val items: List<ContentItem> = emptyList(),
    val status: RowStatus = RowStatus.LOADING,
    val page: Int = 0,
    val totalPages: Int = 1,
    val error: String? = null,
) {
    val hasMore: Boolean get() = page < totalPages && items.size < MAX_ROW_ITEMS
}
