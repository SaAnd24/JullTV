package com.jull.tv.local

import androidx.compose.runtime.Immutable
import com.jull.tv.catalog.ContentItem

enum class WatchStatus(val label: String) {
    PENDING("Pendiente"),
    IN_PROGRESS("En curso"),
    FINISHED("Terminado"),
}

enum class Interest(val label: String) {
    MOVIES("Películas"),
    SERIES("Series"),
    ANIME("Anime"),
    YOUTUBE("Vídeos de YouTube"),
}

@Immutable
data class UserPrefs(
    val interests: Set<Interest> = Interest.values().toSet(),
    val favoriteGenres: Set<String> = emptySet(),
    val excludedGenres: Set<String> = emptySet(),
)

/** Seguimiento local. El progreso, la temporada y el episodio los anota el usuario; JullTV no los mide. */
@Immutable
data class TrackedItem(
    val item: ContentItem,
    val status: WatchStatus,
    val progressPercent: Int?,
    val season: Int?,
    val episode: Int?,
    val sourcePackage: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val lastOpenedAt: Long?,
    val lastReturnAt: Long?,
) {
    fun caption(): String {
        val parts = ArrayList<String>()
        parts.add(status.label)
        progressPercent?.let { parts.add("$it%") }
        if (season != null || episode != null) parts.add("T${season ?: "?"} E${episode ?: "?"}")
        return parts.joinToString(" · ")
    }
}

@Immutable
data class ActivityEntry(
    val key: String,
    val title: String,
    val type: String,
    val atMillis: Long,
    val packageName: String?,
)

@Immutable
data class StoreState(
    val prefs: UserPrefs = UserPrefs(),
    val favorites: List<ContentItem> = emptyList(),
    val tracked: List<TrackedItem> = emptyList(),
    val activity: List<ActivityEntry> = emptyList(),
)
