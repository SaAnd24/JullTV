package com.jull.tv.data

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

@Immutable
data class InstalledApp(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: ImageBitmap,
    /** true si la imagen es un banner 16:9 de la app; false si es su icono. */
    val isBanner: Boolean,
    /** true si la actividad se declara con CATEGORY_LEANBACK_LAUNCHER. */
    val isTv: Boolean,
) {
    val key: String get() = "$packageName/$activityName"
}
