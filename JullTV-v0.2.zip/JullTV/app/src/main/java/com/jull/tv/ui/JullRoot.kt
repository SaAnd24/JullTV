package com.jull.tv.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jull.tv.data.InstalledApp
import com.jull.tv.util.AppLauncher

@Composable
fun JullRoot(nav: HomeViewModel, catalog: CatalogViewModel) {
    val appsState by nav.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Atrás: vuelve a la pantalla anterior; en el inicio no hace nada (es el launcher).
    BackHandler(enabled = true) { nav.pop() }

    val openApp: (InstalledApp) -> Unit = { AppLauncher.launch(context, it) }
    val screen = nav.current

    Box(Modifier.fillMaxSize()) {
        CinematicBackground()
        // key(): cada entrada de la pila tiene su propia composición (y su propio foco inicial)
        key(nav.backStack.size, screen) {
            when (screen) {
                is Screen.Home -> HomeScreen(
                    nav = nav,
                    catalog = catalog,
                    appsState = appsState,
                    onOpenApp = openApp,
                    onRetryApps = nav::refresh,
                )
                is Screen.AllApps -> AllAppsScreen(
                    state = appsState,
                    onOpenApp = openApp,
                    onRetry = nav::refresh,
                )
                is Screen.Browse -> BrowseScreen(
                    section = screen.section,
                    nav = nav,
                    catalog = catalog,
                    appsState = appsState,
                    onOpenApp = openApp,
                )
                is Screen.Search -> SearchScreen(nav = nav, catalog = catalog, appsState = appsState)
                is Screen.Detail -> DetailScreen(
                    item = screen.item,
                    nav = nav,
                    catalog = catalog,
                    appsState = appsState,
                )
                is Screen.Interests -> InterestsScreen(nav = nav, catalog = catalog)
                is Screen.Tracking -> TrackingScreen(nav = nav, catalog = catalog)
                is Screen.Settings -> SettingsScreen(nav = nav, catalog = catalog, appsState = appsState)
            }
        }
    }
}
